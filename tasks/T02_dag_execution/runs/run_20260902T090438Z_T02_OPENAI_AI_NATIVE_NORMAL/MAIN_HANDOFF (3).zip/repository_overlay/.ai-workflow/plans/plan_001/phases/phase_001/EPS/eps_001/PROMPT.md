# Codex CLI assignment — phase_001 / eps_001

## Launch identity

This handoff is frozen to **CODEX / gpt-5.6-terra / xhigh**. Record that exact product-visible model and effort in the executor evidence. Do not silently substitute another route.

## Primary outcome

From the scored repository root, implement and locally verify the complete CLI specified by root `TASK.md`, so the repository is ready for hidden conformance evaluation. This is one bounded implementation-and-evidence attempt under `plan_001` → `phase_001` → `dic_phase_001_r1` → `eps_001`.

## Read first

Read only what is needed, in this order:

1. `TASK.md` — exact behavior authority.
2. `.ai-workflow/plans/plan_001/phases/phase_001/DIC/README.md`
3. `.ai-workflow/plans/plan_001/phases/phase_001/DIC/REQUESTS.md`
4. `.ai-workflow/plans/plan_001/phases/phase_001/DIC/PLAN.md` and `TEST_MATRIX.md`
5. Existing root implementation/project instructions if present.

Do **not** inspect `.evaluation/` or `CHECKPOINTS/`; those are evaluator material and are not implementation inputs.

## Live context and authority

At Phase creation the task repository had no implementation. You may create or modify the task implementation, project metadata, and tests needed to satisfy `TASK.md`. You may use local shell/tools and `uv`, including ordinary package installation when necessary within the resource policy. You may write Phase execution evidence only under `.ai-workflow/plans/plan_001/phases/phase_001/evidence/`. Treat all other `.ai-workflow/` Plan/DIC/EPS files and root benchmark documentation as read-only authority.

Do not perform benchmark/solution search, external writes, releases/submissions, paid actions, credential use, destructive changes outside this repository, or any material redefinition of the Goal. If the task requires such a change, stop and report it rather than improvising new authority.

## Work

Inspect before editing, then choose the implementation architecture you judge most reliable. Cover the complete DSL/config/parameter/expression/task-execution/output contract, not just the supplied example. The task text and its examples are both acceptance evidence; harmless surface inconsistencies should be handled compatibly when possible (for example, accepting demonstrated field forms) without weakening required syntax/semantic validation.

Create focused automated tests and end-to-end probes for the DIC requests and test matrix. Run focused checks while developing, then a broad final regression. Inspect the final diff and remove temporary artifacts. Preserve every remaining failure or caveat as negative evidence; do not claim success from partial smoke tests.

## Acceptance and verification evidence

The attempt is verifier-ready only if it provides evidence for RQ-001 through RQ-007. At minimum, evidence must demonstrate:

- the exact `uv run --project /app launch.py ...` entrypoint works on a successful pipeline;
- exit `1` for a failed entry task, exit `2` with `SYNTAX_ERROR:` for syntax/TOML failures, and exit `3` with `INVALID_PIPE:` for semantic invalidity;
- typed/default/config/env parameter binding and `${params.*}` / `${workspace}` resolution;
- requires sequencing, expected-failure semantics, control flow, recursion/cycle rejection, run-after-requires behavior, timeout `124`, output/workspace safety, and `clean_cwd`;
- success expressions/builtins including multiline-return validation;
- every CLI stdout line parses as JSON with legal events/job IDs, and `jobs.jsonl` has the required fields, ordering/parentage, run-only stdout/stderr capture, and sanitization;
- an example-derived end-to-end pipeline matching the observable behavior in `TASK.md`.

Capture the final verification transcript at:

`.ai-workflow/plans/plan_001/phases/phase_001/evidence/eps_001_test_log.txt`

Write the durable return record at:

`.ai-workflow/plans/plan_001/phases/phase_001/evidence/eps_001_return.json`

The JSON must have this shape (additional concise fields are allowed):

```json
{
  "handoff_id": "AIW_T02_P001_PH001_EPS001_H001",
  "status": "complete|partial|blocked",
  "launch": {"executor": "CODEX", "model": "gpt-5.6-terra", "effort": "xhigh"},
  "changed_files": ["..."],
  "tests": [{"command": "...", "exit_code": 0, "summary": "..."}],
  "acceptance": [{"id": "RQ-001", "status": "pass|fail|partial", "evidence": "..."}],
  "negative_evidence": ["..."],
  "remaining_issues": ["..."]
}
```

List all RQ-001..RQ-007 entries. Record actual commands and exit codes. If a check fails and you repair it, retain the failed observation in `negative_evidence` and record the later passing rerun separately.

## Stop / return contract

Return to Main rather than changing the DIC if you encounter a material Goal ambiguity that cannot be satisfied compatibly, an authority/resource boundary, or a defect that requires redefining acceptance. Ordinary code/test defects are in scope: repair them within this attempt and rerun affected checks.

At the end, leave the repository with the best in-scope implementation you can establish now, write both evidence files above, and return a concise terminal summary containing: handoff ID; exact launch model/effort; `complete|partial|blocked`; changed task files; verification commands with pass/fail; evidence paths; unresolved issues/negative evidence. Do not omit failed checks.
