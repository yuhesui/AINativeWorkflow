# Plan 001 — Build and verify pipeline CLI

## Goal

Implement the exact root `TASK.md` pipeline/config CLI contract to evaluator-ready quality. The Plan is adaptive: it does not predeclare a fixed number of Phases.

## Current Phase

- `phase_001` — Complete CLI implementation and conformance evidence.
- Status: active; DIC revision 1; `eps_001` prepared for the frozen Codex route.

## Main decisions

- Research: not needed.
- Theory/Experiment specialist workstreams: not needed for this software-conformance Phase.
- Implementation architecture is intentionally delegated to the executor; the exact behavior and evidence requirements are fixed by the Goal and DIC.
- Evidence-gated transition after each executor attempt: `accept | repair | replan | escalate`. Ordinary defects stay in `phase_001` with a new EPS; failures and negative evidence are retained.
- Protected evaluator material is out of scope.

## Closure condition

Close the Plan when the active Phase is accepted against every acceptance-bearing request and no unresolved blocker remains. If material new work is discovered, Main may add a subsequent Phase rather than rewriting executed history.
