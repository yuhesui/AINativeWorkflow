# Phase Requests and Acceptance

## RQ-001 — Entrypoint and process contract

- [ ] Outcome: The repository exposes the required `launch.py` CLI and is runnable through `uv run --project /app launch.py <pipeline> --workspace <dir> --output <dir> [--config <TOML>]`.
- Acceptance: successful entry-task completion exits `0`; failed entry task exits `1`.
- Acceptance: bad TOML or pipeline syntax exits `2` and writes exactly a `SYNTAX_ERROR:<msg>`-prefixed diagnostic to stderr; semantic/validation invalidity exits `3` with `INVALID_PIPE:<msg>`.
- Evidence: focused subprocess tests plus at least one end-to-end successful invocation.
- Verifier: recompute representative exit-code/error-prefix cases.

## RQ-002 — Pipeline/config parsing and typed parameter binding

- [ ] Outcome: Tasks, ordered typed parameters/defaults, config entry invocation, config environment variables, and dynamic `${params.*}` / `${workspace}` resolution follow `TASK.md`.
- Acceptance: scalar defaults and environment-derived defaults are type-cast/validated; list defaults remain type-safe; required/default ordering and missing/type-mismatched arguments are rejected in the required error class.
- Acceptance: task validity (`run` or `requires`) and undefined references are enforced.
- Evidence: automated parsing/binding tests covering valid and invalid cases.
- Verifier: inspect tests and independently rerun a representative subset.

## RQ-003 — Requires execution semantics

- [ ] Outcome: Dependency task calls execute sequentially with correct blocking/inversion semantics, parameter passing, control flow, and parent/job lineage.
- Acceptance: ordinary calls block the caller after an unexpected failure; `fail(...)`/compatible failure-expectation form continues only when the called task fails; task calls under conditionals obey expression control flow.
- Acceptance: loops/conditionals, variables, indexing, arithmetic/string operators, break/continue/return required by the Goal work; recursive/circular task execution is rejected rather than recursing indefinitely; no job caching occurs.
- Evidence: behavioral tests asserting call order, stopping behavior, recursion rejection, and job parentage.
- Verifier: rerun the example-like dependency chain and at least one negative branch.

## RQ-004 — Run, workspace, output, cleanup, timeout

- [ ] Outcome: Each job applies requires before run, executes run commands with parameter/workspace/environment resolution, and handles task output directories/workspace safely.
- Acceptance: relative task output paths resolve according to the Goal, `${workspace}` overrides relative placement as specified, and workspace-escaping paths are rejected with `INVALID_PIPE`.
- Acceptance: `clean_cwd` behavior is honored and job timeouts produce `timed_out=true` and `exit_code=124`.
- Evidence: filesystem/subprocess tests including timeout and path-safety cases.
- Verifier: inspect resulting workspace/output trees and rerun timeout/path probes.

## RQ-005 — Success expressions

- [ ] Outcome: Success checks use the required expression language and builtins and combine with run exit status exactly as the Goal specifies.
- Acceptance: default success is run exit code `0`; empty success is valid; named checks evaluate to booleans after run; multiline success bodies require an explicit return or raise `SYNTAX_ERROR`.
- Acceptance: `len`, `contains`, `equals`, `exists`, control flow, comparison/logical/arithmetic operations, indexing, and file/stdout/stderr/exit-code targets needed by `TASK.md` behave as specified.
- Evidence: automated success-expression tests including file/stdout/stderr and a missing-return syntax case.
- Verifier: rerun representative pass/fail success checks.

## RQ-006 — Observable logging and jobs.jsonl

- [ ] Outcome: Every stdout log line emitted by the CLI is valid JSON with required `event` and 1-based `job_id`, using only the allowed event values; the output directory contains the required `jobs.jsonl` job records.
- Acceptance: job records contain the required fields/types, completion-order records, correct parent IDs, timeout/exit status, success map, task output path, duration, and sanitized run stdout/stderr.
- Acceptance: recorded stdout/stderr contain only the task `run` process streams, not evaluator/internal diagnostics; curly single quote `‘` is normalized to `'` as required.
- Evidence: JSON parsing assertions over CLI stdout and exact-field assertions over `jobs.jsonl`.
- Verifier: parse all emitted lines and compare a deterministic small pipeline against expected ordering/content.

## RQ-007 — Integration quality and retained evidence

- [ ] Outcome: The implementation is maintainable enough to support the contract and passes a broad local regression suite within the resource policy.
- Acceptance: focused tests cover the principal positive, negative, edge, and example-derived behaviors rather than only smoke execution.
- Acceptance: the final executor report lists every verification command and exit code, changed task files, unresolved caveats, and all negative evidence; no failed check is silently omitted.
- Evidence: `.ai-workflow/plans/plan_001/phases/phase_001/evidence/eps_001_return.json` plus a captured test log.
- Verifier: Main independently adjudicates `accept | repair | replan | escalate` from reproducible evidence.

## Failure representation

Each request may be `complete`, `partial`, `blocked`, `negative-result`, `superseded`, or `abandoned`. A failed test or incomplete feature remains visible and normally triggers a fresh EPS under this same DIC.
