# Phase 01 Test Matrix

This matrix is acceptance guidance, not a prescribed implementation architecture. The executor may consolidate cases while preserving coverage and reproducibility.

| Area | Minimum decisive probes |
|---|---|
| CLI / config | required arguments; optional TOML; default `main`; configured positional/named entry params; `clean_cwd`; `[env]` propagation |
| Parse / types | all scalar/list parameter types; defaults; env-default casts; invalid default ordering; missing args; duplicate/unknown args; undefined tasks; task missing both `run` and `requires` |
| Syntax vs invalid pipe | malformed TOML/DSL → exit 2 + `SYNTAX_ERROR:`; semantic validation/type/cycle/path violations → exit 3 + `INVALID_PIPE:` |
| Requires | sequential execution; ordinary failure blocks; expected-failure call continues only on failure; loops; if/elif/else; variables; array indexing; break/continue; recursion/cycle rejection; no caching |
| Run | parameter/workspace/env interpolation; shell stdout/stderr capture; requires-before-run; run-after-successful-requires; timeout → 124 |
| Output/workspace | relative task output resolution; `${workspace}` override; safe creation; workspace escape rejection; `--output` jobs file generation |
| Success | default exit-code check; empty map; named one-line expression; multiline return; missing return syntax error; exists/contains/equals/len; file/stdout/stderr/exit-code operands; regex/exact containment |
| Events / jobs | every CLI stdout line valid JSON; legal events; 1-based deterministic IDs; parent IDs; completion-order JSONL; required fields; run-stream-only capture; quote normalization |
| Example-derived E2E | adapt the `echo_hello` / `readResults_` example and verify job ordering, expected initial failure, two writes, final success, `results.txt`, and `jobs.jsonl` |
