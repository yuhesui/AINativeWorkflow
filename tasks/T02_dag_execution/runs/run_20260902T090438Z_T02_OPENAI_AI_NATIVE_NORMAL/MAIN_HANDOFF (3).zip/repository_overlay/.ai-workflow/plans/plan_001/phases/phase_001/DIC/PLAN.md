# Durable Phase Execution Graph

Main owns this whole-Phase topology. `eps_001` realizes the ready machine-execution nodes. Main performs the terminal evidence gate after the executor returns.

```mermaid
flowchart TD
    N01["N01 · Recover task contract and repository baseline"] --> N02["N02 · Implement complete CLI semantics"]
    N02 --> N03["N03 · Build and run conformance/regression tests"]
    N03 --> N04["N04 · Integrate repairs, inspect final diff, preserve evidence"]
    N04 --> G{"Main evidence gate"}
    G -->|accept| C["Close Phase"]
    G -->|repair| R["Fresh EPS on affected nodes"]
    R --> N03
    G -->|replan / escalate| M["Return to Main for material decision"]
```

## Node contract

| Node | Primary outcome | Depends on | Owner | Reads | Writes | Evidence target | Gate |
|---|---|---|---|---|---|---|---|
| N01 | Establish the actual repository baseline and extract the exact task contract/edge cases before editing. | — | Codex Orchestrator | `TASK.md`, root instructions, active DIC/EPS | none except transient notes | baseline and implementation plan reflected in final report | N02 |
| N02 | Deliver a complete implementation of the pipeline parser/config binder/expression evaluator/task executor/CLI/output contract. | N01 | Codex Orchestrator | task contract + repository | task code, project metadata, tests | runnable implementation covering RQ-001..RQ-006 | N03 |
| N03 | Exercise the contract with focused automated and end-to-end tests, including negative/error cases. | N02 | Codex Orchestrator | implementation + `TEST_MATRIX.md` | tests and local temporary artifacts only | commands, exit codes, test results, observed defects | N04 |
| N04 | Repair in-scope defects found by N03, rerun affected/broad checks, inspect diff, and write durable executor evidence without hiding failures. | N03 | Codex Orchestrator | implementation/test results | task code/tests plus Phase `evidence/` only | `eps_001_return.json`, test log, clean final diff | Main gate |

## Execution policy

- The current implementation is tightly shared state, so this DIC does not require parallel write branches. Codex may use isolated read-only/subagent review if the surface supports it and the parent integrates the result, but correctness may not depend on unavailable subagents.
- Incidental architecture, parser technology, module structure, and test organization are executor choices.
- Focused checks precede broad regression checks. Temporary files must be removed or confined to test temp directories.
- Do not inspect `.evaluation/` or `CHECKPOINTS/`; do not modify benchmark documentation or DIC/Plan authority.
- Local dependency installation through the provided `uv` environment is allowed when necessary. No benchmark/solution search, external writes, paid resources, credentials, release, or submission.

## Evidence semantics

Main accepts only reproducible evidence. If any acceptance-bearing behavior remains unimplemented or a verification command fails, report it as negative evidence. Ordinary implementation defects result in `repair` and a new EPS bound to this unchanged DIC. A change to the Goal, required behavior, authority, or a genuinely irreconcilable specification conflict requires `replan` or `escalate`.
