# Phase 001

**Objective:** deliver the complete task CLI and reproducible conformance evidence.

- Plan: `plan_001`
- DIC: `dic_phase_001_r1`
- Active EPS: `eps_001`
- Frozen route: `CODEX / gpt-5.6-terra / xhigh`
- Main gate after return: `accept | repair | replan | escalate`
- Ordinary repair policy: preserve this DIC; create a new handoff ID and EPS instance for the affected nodes.

Read `DIC/README.md` → `DIC/REQUESTS.md` → `DIC/PLAN.md` → `DIC/TEST_MATRIX.md` → active EPS prompt.
