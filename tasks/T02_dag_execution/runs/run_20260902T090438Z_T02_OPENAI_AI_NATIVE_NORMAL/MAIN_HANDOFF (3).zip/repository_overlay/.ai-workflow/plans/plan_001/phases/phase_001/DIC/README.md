# Phase 01 — Complete CLI implementation and conformance evidence

## Orientation

This is the first active Phase of `plan_001`. The repository begins without a task implementation. The bounded outcome is a complete, locally verified CLI satisfying the exact benchmark contract in root `TASK.md`.

**Authority order**

1. Root `TASK.md` — exact product/behavior contract.
2. This Phase DIC (`README.md`, `REQUESTS.md`, `PLAN.md`, `TEST_MATRIX.md`).
3. `EPS/eps_001/PROMPT.md` — just-in-time Codex realization of the DIC; it may choose incidental implementation details but may not change acceptance or authority.
4. Existing repository instructions, if any, provided they do not conflict with the Goal/DIC.

## Durable context

- Plan: `plan_001`
- Phase: `phase_001`
- DIC: `dic_phase_001_r1`
- Research: not needed. This is a local software-conformance task; external evidence would not change the required behavior.
- Core workstreams: `M ✓ · T — · E —`
- Frozen executor route for the current attempt: `CODEX / gpt-5.6-terra / xhigh`.
- No task implementation existed when this Phase was planned.

## Interpretation boundaries

The task specification and its examples are both acceptance evidence. Where the text contains a harmless surface inconsistency (for example a shown form with or without a field colon, or `fail`/`fails` wording), prefer a compatible parser behavior that accepts the demonstrated forms without weakening required validation or error classification. Do not invent unrelated language features.

Do not read or alter evaluator-private material. `.evaluation/` and `CHECKPOINTS/` are outside execution scope. Root benchmark documentation is read-only.

## Evidence gate

The executor returns implementation plus reproducible local evidence. Main then adjudicates exactly one of `accept`, `repair`, `replan`, or `escalate`. Ordinary implementation/test defects are `repair` under this same DIC with a fresh EPS; negative evidence is retained.
