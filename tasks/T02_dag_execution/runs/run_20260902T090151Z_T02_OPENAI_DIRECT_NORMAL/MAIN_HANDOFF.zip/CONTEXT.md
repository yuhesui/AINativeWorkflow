# Main context — Direct T01

The operator supplied the complete Direct-condition task repository in `MAIN_INPUT.zip`. Main inspected it without modifying the database.

Authoritative repository files at executor time:

- `/app/TASK.md` — frozen task prompt.
- `/app/RESOURCE_POLICY.md` — ceiling: 90 minutes wall time, 60 executor-minutes, one concurrent executor, 4 CPU cores, 8 GiB RAM, 2 GiB writable disk, no GPU; network disabled except experiment control.
- `/app/my-sql-query.sql` — baseline query to optimize.
- `/app/oewn.sqlite` — OEWN SQLite database; must remain unmodified.
- `/app/README_EVALUATION.md` — confirms this is the complete agent-facing Direct repository and that hidden evaluator material is excluded.

Read-only schema inspection found no persistent indexes for `words`, `senses`, or `synsets`. Approximate table sizes are 152,332 `words`, 212,508 `senses`, and 120,569 `synsets` rows.

The baseline plan builds temporary B-trees for grouping/distinct aggregates and contains correlated scalar subqueries that repeatedly scan `senses`, including a nested rescan to recompute the top synset. This is context only, not a prescribed implementation strategy.

No hidden expected answer, evaluator checkpoint, private reference solution, or external workflow artifact is included in this handoff.
