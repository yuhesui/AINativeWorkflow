# Executor return contract

The scored artifact is `/app/sol.sql`.

On success:

- `/app/sol.sql` exists.
- It contains exactly one SQLite query, no comments, and ends with a semicolon.
- Its complete ordered output on `/app/oewn.sqlite` exactly matches `/app/my-sql-query.sql`.
- The database remains unmodified.
- No repository file other than `/app/sol.sql` is changed.

The executor final response must contain exactly these labeled sections in this order:

STATUS: SUCCESS or BLOCKED with a one-line reason.

SOLUTION_PATH: `/app/sol.sql` if successful.

VERIFICATION: concise evidence for exact ordered-output equivalence, query-plan improvement, timing evidence (or why complete timing was infeasible), and final-file-format validation.

CHANGED_FILES: repository files changed; on success this must be only `/app/sol.sql`.
