# Direct executor assignment — T01 SQLite query optimization

## Frozen launch route

Run this assignment with **Codex CLI**, product-visible model **gpt-5.6-terra**, reasoning effort **xhigh**. Do not silently substitute another model or effort. If the actual launch route differs, report the mismatch rather than proceeding under a different route.

## Outcome

Optimize the SQL in `/app/my-sql-query.sql` as aggressively as is safely possible while preserving exactly the same query output. Write the final answer to `/app/sol.sql`.

## Repository context

Work from the scored repository root, expected to be `/app`. The authoritative task is `/app/TASK.md`; resource limits are in `/app/RESOURCE_POLICY.md`; the unoptimized query is `/app/my-sql-query.sql`; the OEWN SQLite database is `/app/oewn.sqlite`.

Main performed read-only inspection only. The relevant facts are:

- `words`: 152,332 rows; columns include `wordid`, `word`.
- `senses`: 212,508 rows; columns include `senseid`, `synsetid`, `wordid`, and others.
- `synsets`: 120,569 rows; columns include `synsetid`, `posid`, `domainid`, `definition`.
- There are no persistent indexes on these three tables in the supplied database.
- The baseline `EXPLAIN QUERY PLAN` uses temporary B-trees for grouping/distinct aggregates and, critically, correlated scalar subqueries that repeatedly scan `senses` for `top_synsetid` and `top_synset_sense_count`.

Use only the supplied repository and local tooling. Do not import or reconstruct any external workflow framework or hidden benchmark material.

## Scope and authority boundaries

You may read any supplied repository file needed to understand or verify the task. You may inspect the database schema, run read-only queries, use `EXPLAIN QUERY PLAN`, and benchmark candidate queries. You may create temporary test artifacts outside the repository if useful.

The **only repository file you may create or modify is `/app/sol.sql`**. Do not modify `/app/oewn.sqlite` in any way. Do not create persistent indexes, run `VACUUM`, `ANALYZE`, writable PRAGMAs, or otherwise change database contents or metadata. Prefer opening the database read-only during verification.

Do not modify `TASK.md`, `RESOURCE_POLICY.md`, `README_EVALUATION.md`, or `my-sql-query.sql`.

## Required solution format

`/app/sol.sql` must contain:

- exactly one SQLite query;
- no SQL comments;
- a terminating semicolon;
- no non-SQL prose.

## Success criteria

1. The candidate produces exactly the same ordered rows and values as `/app/my-sql-query.sql` on the supplied `/app/oewn.sqlite`.
2. The candidate is materially more efficient than the baseline and is optimized as far as practical under the fixed schema and no-database-modification constraint.
3. The query is valid SQLite syntax and executes against the supplied database.
4. Only `/app/sol.sql` is changed in the repository.

## Verification and evidence

Before finishing, perform enough read-only verification to justify equivalence and the optimization. At minimum:

- execute both baseline and candidate and compare their complete ordered outputs exactly, not merely row counts or unordered sets;
- confirm the candidate returns the expected limited result without runtime errors;
- inspect `EXPLAIN QUERY PLAN` for the candidate and check that the dominant repeated correlated rescans have been removed or otherwise substantially reduced;
- obtain reproducible wall-clock timing evidence for baseline versus candidate when feasible within the resource ceiling, using the same database and comparable conditions;
- validate the final `/app/sol.sql` format: one query, no comments, terminated by `;`;
- verify repository changes are limited to `/app/sol.sql`.

If the baseline is unusually slow, remain within the stated resource ceiling and use sound partial timing/plan evidence rather than modifying the database to accelerate testing.

## Evidence to preserve

Preserve in your final response the equivalence result, candidate query-plan summary, timing comparison (or a precise explanation if full timing was infeasible), and changed-file check. Temporary test files need not be returned.

## Exact return contract

Follow `/app/RETURN_CONTRACT.md` if that file is present after handoff import. In all cases, finish with exactly these four labeled sections in this order:

`STATUS:` `SUCCESS` or `BLOCKED` with a one-line reason.

`SOLUTION_PATH:` `/app/sol.sql` if successful.

`VERIFICATION:` concise evidence covering exact ordered-output equivalence, query-plan improvement, timing evidence, and final-file-format validation.

`CHANGED_FILES:` list repository files changed; on success this must be only `/app/sol.sql`.
