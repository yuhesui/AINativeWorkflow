# `.ai-workflow/` Runtime

This is the only operative part of the surrounding development package. It can be adopted wholesale or used to formalize an existing ChatGPT/Claude + research + coding-agent workflow.

- Main is a persistent planning/decision chat.
- Each Phase has exactly one multi-view DIC with `README.md`, `REQUESTS.md`, and `PLAN.md`.
- `DIC/PLAN.md` stores the durable sequence, dependencies, parallelism, subagent branches, merge nodes, and conditional repair/review graph.
- Orchestrator is a coding-agent session that realizes DIC nodes as JIT, model-tuned EPS prompts and manages Workers/subagents.
- Research is advisory: `Main → Research → Main reconciliation → DIC/execution`.

Start with `docs/CORE.md` and the relevant role guide.


## Practical objective

Reduce human attention spent on routine coordination, context reconstruction, and execution supervision per unit of verified progress. Preserve human attention for scientific objectives, surprising evidence, material method changes, claim boundaries, and external responsibility. This is a target for evaluation, not an already-proven performance gain.
