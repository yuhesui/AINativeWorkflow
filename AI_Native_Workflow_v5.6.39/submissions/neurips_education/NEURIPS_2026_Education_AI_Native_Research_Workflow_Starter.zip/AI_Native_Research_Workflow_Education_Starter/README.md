# AI Native Workflow for Research — NeurIPS 2026 Education Starter

Presenter: **Yuhe Sui, Quantitative Research Society @ NTU**.

This teaching starter formalizes the multi-surface AI workflow many researchers already use. It includes the v5.6.39 runtime, the full 15–20 minute slide plan, teaching-material plans, a learner exercise, demo/facilitator notes, an annotated reading list, and the current two-page concept outline. The runtime demonstrates the durable Goal → Plan → Phase → DIC → EPS hierarchy, Main-authored initial EPS/prompt graph, coding-agent execution, evidence lineage, verification, and dependency-local repair.

Human-attention and long-horizon efficiency gains remain evaluation targets rather than established comparative results.
