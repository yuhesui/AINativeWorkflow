# Immediate next actions — 30 August 2026

This file is the human-facing execution order for the current deadline window. It does **not** replace `.ai-workflow/STATE.json`; Phase 01 remains the next machine engineering Phase.

## A. Before Phase 01: deadline-critical publication actions

### A1 — Who Verifies the Agents? demo conversion

**Deadline:** 29 August 2026 AoE = **30 August 2026, 19:59 Singapore time**.

Use `submissions/who_verifies/DEMO_PAPER_XHIGH_PROMPT.md` in a fresh GPT-5.6 XHigh session with the complete package attached. The current 5-page research-style draft is source material, **not the intended final submission**. Reconstruct it as a self-contained ≤4-page demo paper centered on the implemented verification-gated system, concrete execution evidence, and dependency-local repair. Do not invent the pending benchmark results.

Human release gate after XHigh returns:

1. verify official NeurIPS 2026 formatting and anonymity;
2. inspect the final PDF;
3. verify citations and factual claims;
4. confirm title/abstract/form fields;
5. submit on OpenReview only by explicit human action.

### A2 — AutoMLR eligibility + abstract registration

**Abstract deadline:** workshop page lists **29 August 2026**, with exact timezone delegated to the live submission instructions. Treat this as immediate.

Use `submissions/automlr/AUTOMLR_ABSTRACT_XHIGH_PROMPT.md` in a separate fresh GPT-5.6 XHigh session with the complete package attached.

The current package contains **no completed scored workshop experiment**, so it cannot honestly assert that the planned Flat-vs-Workflow study has already produced a qualifying ML result. The XHigh session must first audit whether another existing package-resident result genuinely meets AutoMLR's autonomous-ML-research requirement. If not, it must return `NOT YET ELIGIBLE` rather than fabricate a result.

If the live OpenReview portal allows registration and the eligibility audit supports a defensible abstract, register it by explicit human action. Final paper deadline is **5 September 2026**.

## B. Phase 01 — engineering/environment release

After the immediate submission actions, execute `NEXT_PHASE01_CODING_AGENT_HANDOFF.md` with coding agents.

Phase 01 is responsible for:

- CLI cleanup and compatibility repair;
- repository hygiene and version preservation;
- official NeurIPS author-kit integration;
- GitHub remote creation/push after authentication and ownership checks;
- Harbor/benchmark environment preparation;
- non-scored oracle/verifier qualification.

It must not run scored Flat/Workflow trials.

## C. What scientific work remains?

**Mostly the experiment.** The architecture, detailed technical specification, formal theory, literature synthesis, experiment protocol, and substantive workshop drafts already exist.

The main missing scientific evidence is:

1. qualify/freeze the five benchmark environments;
2. run the 10 primary paired Flat/Workflow trajectories;
3. run the four pre-declared T2/T3 replications if resources permit;
4. reconcile the raw evidence without hiding negative/null results;
5. insert the confirmed results into Meta-Agents and, if appropriate, AutoMLR.

The experiment is therefore the principal remaining *research* task. It is not the only remaining *operational* task: deadline submission work and Phase 01 engineering still precede it.

## D. Venue-specific state

- **Who Verifies:** use the demo route now; it does not require the 14-run study to make a defensible implemented-system submission.
- **Meta-Agents:** keep the full-paper route. The experiment is the main missing evidence before the 5 September deadline.
- **AutoMLR:** eligibility is conditional. A qualifying autonomous ML result is mandatory; a systems-only workflow paper is insufficient.
