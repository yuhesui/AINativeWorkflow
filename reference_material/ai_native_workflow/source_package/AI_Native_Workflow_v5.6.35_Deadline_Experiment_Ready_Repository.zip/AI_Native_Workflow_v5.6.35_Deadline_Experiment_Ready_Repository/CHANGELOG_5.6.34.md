# Changelog — v5.6.34

## Workshop proof-of-concept programme

- Added an approved six-Phase Plan `plan-workshop-poc-evaluation`.
- Prepared Phase 01 for coding agents: CLI cleanup, repository hygiene, GitHub publication after auth checks, official NeurIPS-template integration, and five-task Harbor environment preparation.
- Froze a resource-constrained five-task/14-run study using ChatGPT as Main, Claude Pro A for 10 core executions, and Claude Pro B for four pre-declared hard-task replications.
- Preserved the broader C0–C3/horizon/fault programme as `experiments/FULL_RESEARCH_PROTOCOL_FUTURE.md` rather than pretending the workshop study is a full benchmark paper.
- Added task catalogue, F/W condition contract, model budget, run matrix, environment-preparation guide, evidence/analysis rules, JSON run schema, task-lock template, and non-destructive preparation scripts.

## Repository/versioning

- Initialized the package as a local Git repository.
- Imported the detailed v5.6.33 package as the historical baseline and retained its annotated tag.
- Added a workshop-specific routing profile that records ChatGPT Main / Claude Code account roles while requiring the actual surfaced models to be recorded at run time.
- GitHub creation/push is deliberately deferred to Phase 01; no remote publication occurs in this release preparation.

## Publications

- Rewrote the Meta-Agents draft around persistent contracts and management of long-horizon agent work.
- Rewrote the Who Verifies draft around verification-gated recovery, evidence lineage, and dependency-local repair.
- Rebuilt AutoMLR as a conditional 4+4+1 scaffold with explicit human-rewrite markers and no fabricated qualifying result.
- Added an official-requirements audit and explicit official-author-kit integration task for Phase 01.
- Expanded the detailed technical report's empirical section to describe the five-task/14-run workshop protocol while preserving the larger future programme.

## Scientific boundary

No scored F/W benchmark run is included in v5.6.34. Existing tests/fixtures are engineering evidence only. Manuscript result claims remain explicitly pending.
