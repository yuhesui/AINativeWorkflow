# Build status — v5.6.35

- Current retained PDF: **5 pages total**.
- Current retained draft role: **source material only**.
- Intended final route: **Who Verifies demo paper, ≤4 main-text pages**.
- XHigh reconstruction prompt: `DEMO_PAPER_XHIGH_PROMPT.md`.
- Comparative workshop experiment: **0/14 scored runs**, therefore no comparative result may be inserted yet.
- Current PDF compiles with resolved citations, but it is not the intended final demo submission.
