# GPT-5.6 XHigh — Who Verifies the Agents? 2026 Demo Paper Reconstruction

## Role

Act as the senior scientific author, verification researcher, agent-systems researcher, and NeurIPS workshop editor responsible for producing the strongest scientifically defensible **demo-paper submission** from the attached complete AI-Native Workflow package.

Use GPT-5.6 XHigh reasoning quality throughout.

This is a paper-writing and package-integration task, not a new research phase. Read the complete package before drafting. Treat package state/evidence as authoritative. Do not infer results from prior chat or invent any unrun benchmark result.

## Venue

Target: **Who Verifies the Agents? @ NeurIPS 2026**.

Before editing, verify the live official workshop page and NeurIPS 2026 author instructions. Current intended constraints are:

- demo paper;
- **≤4 main-text pages**;
- NeurIPS 2026 template;
- double blind;
- non-archival;
- references/appendices handled per live rules;
- accepted work is presented as posters, with selected oral/lightning presentations.

If the live official rules conflict with this package, the live official rules win and the discrepancy must be recorded.

## Central objective

Replace the current research-style Who Verifies draft with a polished, self-contained 4-page demo paper centered on an **implemented verification-gated long-horizon execution system**.

The central systems object is approximately:

> persistent intent + hierarchical refinement + bounded execution + evidence-grounded verification + dependency-local repair or upward replanning.

Do **not** make the primary claim that AI-Native Workflow empirically outperforms flat agent systems. The package currently records 0/14 scored workshop trajectories unless new package evidence proves otherwise.

The strongest current evidence is instead:

1. implemented Plan → Phase → one multi-view DIC → EPS → Prompt/Run → Action machinery;
2. persistent requests, execution plan, evidence references, and state recovery;
3. verification outcomes: accept / repair / replan / escalate;
4. dependency-aware invalidation/local repair;
5. inspectable provenance and flat merged-raw phase reports;
6. engineering/runtime test evidence;
7. formal statements under explicit assumptions;
8. a concrete structural/runtime demonstration or real retained execution trace.

## Read first

At minimum inspect:

- `00_READ_FIRST.md`;
- `.ai-workflow/STATE.json`;
- `.ai-workflow/docs/PHASE_DIC_EPS_STRUCTURE.md`;
- `README.md`, `QUICKSTART.md`, `VERSIONING.md`;
- `AI_NATIVE_WORKFLOW_TECHNICAL_REPORT.tex`;
- `research/CLAIM_LEDGER.json` and theory/literature notes;
- `.ai-workflow/aw/` runtime code and relevant tests;
- current `submissions/who_verifies/main.tex`;
- current Meta-Agents draft only as contrast/source material;
- `experiments/workshop_poc/` only to describe planned evidence correctly;
- phase reports/raw evidence that support any worked demo.

Recover exact implemented semantics rather than relying on top-level summaries alone.

## Required framing

The paper should answer immediately:

1. What is difficult about verifying long-horizon agents?
2. What execution state does this system expose that ordinary loops often leave implicit?
3. How does verification alter ongoing execution rather than merely grade a final answer?
4. What can a reviewer inspect/run today?

A suitable title is **Verification-Gated Hierarchical Execution for Long-Horizon Agents**, but choose a more precise title if the package supports one.

Do not foreground version numbers or product branding in the title unless scientifically useful.

## Preferred four-page structure

### Page 1 — Problem + demo contribution

- concise verification problem;
- unsupported completion, hidden regression, and broad restart failure modes;
- system overview;
- 3–4 compact evidence-backed contributions.

Avoid generic Transformer/agent background.

### Page 2 — Verification-gated architecture

Explain the chain:

`Goal → Plan → Phase → DIC → EPS → Prompt/Run → Action → Evidence → Verify`.

Represent DIC correctly as **one multi-view package per Phase**, not sequential DIC substeps:

- `README.md`: general Phase summary;
- `REQUESTS.md`: concrete goals to achieve;
- `PLAN.md`: durable execution graph including prompt IDs, dependencies, parallel subagents, merge nodes and conditional branches;
- `ARCHITECTURE.md`: target repository/system architecture when relevant;
- `TEST_MATRIX.md`: actual software/theory/experiment test matrix when relevant;
- arbitrary user-defined custom DIC views are allowed.

Explain EPS as the just-in-time runnable instantiation/refinement of durable plan nodes.

Make verification outcomes explicit: **accept / repair / replan / escalate**.

### Page 3 — Concrete demo trace

This is the centerpiece.

Find the strongest real package-resident execution/recovery trace. Show something like:

request → plan node → EPS run → action/evidence → verification failure → affected dependency cone → local repair → re-verification → acceptance.

If historical fine-grained execution is unavailable because an earlier package version did not retain it, do **not** reconstruct fictional events. Use an implemented deterministic fixture/runtime demonstration and label it explicitly as structural/demo evidence rather than confirmatory agent-performance evidence.

Include exact artifact/evidence references where useful.

### Page 4 — Formal insight + implementation validation + limitations

Include only the most useful compact formal statement, preferably dependency-local recovery under explicit assumptions such as complete declared dependencies, version-bound evidence, and no undeclared mutable inputs.

Then report only completed validation:

- runtime test status;
- package recovery/lineage validation;
- structural demo outcome;
- other directly supported engineering evidence.

Clearly state that the five-task/14-run Flat-vs-Workflow benchmark is planned/ongoing if still unexecuted.

End with limitations: incomplete declared dependencies, verifier observability, conditional guarantees, short-task overhead, and lack of broad comparative performance evidence.

## Figures

Use at most two high-information figures. Prefer:

1. verification-gated execution architecture;
2. concrete dependency-local repair trace.

No decorative figures.

## Scientific integrity

Strictly prohibit:

- invented benchmark results;
- invented latency/token savings;
- invented deployments or users;
- invented citations;
- treating 55/55 implementation tests as evidence of agent-performance superiority;
- treating deterministic fixtures as confirmatory comparative evidence;
- claiming theorem novelty without literature support;
- implying the SlopCodeBench/Terminal-Bench study already ran.

Classify evidence correctly as implementation test, structural/demo evidence, mathematical result, planned experiment, or hypothesis.

## Related work

Keep it compact and nearest-neighbour only:

- verifier-guided/self-refining agents;
- long-horizon agent evaluation;
- hierarchical/plan-and-execute agent systems;
- harness/scaffold optimization;
- runtime verification and environment-grounded evaluation.

Do not use “hierarchical planning” alone as novelty.

Verify important citations against primary sources.

## Deliverables

Modify/create:

- `submissions/who_verifies/main.tex`;
- bibliography and figures;
- authoritative NeurIPS 2026 template/style where permitted;
- `CHECKLIST.md`;
- `VENUE_REQUIREMENTS.md` or equivalent requirement record;
- compiled `main.pdf`.

Do not modify Meta-Agents just to harmonize wording. Do not submit externally.

## Build/audit

After drafting:

1. compile LaTeX;
2. enforce ≤4 main-text pages;
3. visually inspect the PDF;
4. check double-blind anonymity;
5. map every quantitative statement to package evidence;
6. verify citations;
7. reconcile formal claims with the claim ledger;
8. remove generic exposition before removing mechanism detail;
9. ensure the demo is understandable without the 46-page technical report;
10. run a hostile final reviewer pass focused on verification relevance, runnable artifact, concrete demo, and claim/evidence proportionality.

## Final response

Return:

1. final title;
2. one-paragraph actual contribution summary;
3. exact page count;
4. strongest evidence included;
5. strongest limitation;
6. files changed;
7. build status;
8. remaining submission blocker.

The primary deliverables are the finished `.tex` and PDF.
