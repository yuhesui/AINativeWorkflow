# Who Verifies the Agents? submission checklist — v5.6.35

Status: **deadline-critical demo conversion required**.

The retained `main.tex` / `main.pdf` are the previous 5-page research-style draft and are source material only. The intended submission is now a **≤4-page demo paper**.

- [x] Verification, evidence lineage, unsupported completion, local repair, upward replanning, and escalation are central.
- [x] Implemented runtime/package evidence exists.
- [x] Anonymous source; no identifying acknowledgements in the current draft.
- [x] Formal locality/verifier claims retain explicit assumptions and limits.
- [x] Five-task/14-run protocol is written and explicitly unexecuted; no comparative result fabricated.
- [x] Demo-track decision recorded in `DEMO_TRANSITION.md`.
- [x] Full XHigh reconstruction prompt prepared in `DEMO_PAPER_XHIGH_PROMPT.md`.
- [ ] Run the XHigh demo-paper reconstruction with the full package attached.
- [ ] Enforce **≤4 main-text pages** under the authoritative NeurIPS 2026 template.
- [ ] Include one concrete real/structural verification-repair demonstration.
- [ ] Fresh correctness/evidence/citation/anonymity audit.
- [ ] Visually inspect final PDF.
- [ ] Human confirmation before external submission.

Official deadline snapshot: **29 August 2026 AoE = 30 August 2026 19:59 Singapore time**.
