# Who Verifies — demo-track transition

## Decision

The intended current submission is a **demo paper of at most 4 main-text pages**, not the existing 5-page research-paper draft.

The existing `main.tex` / `main.pdf` are retained as source material so the XHigh reconstruction can reuse verified prose, citations, theory, and figures. They are **not submission-ready in their present form**.

## Why the demo format is preferred now

Current evidence is strongest on:

- an implemented verification-gated runtime;
- persistent DIC/EPS/Prompt-Run state and evidence lineage;
- accept / repair / replan / escalate semantics;
- package recovery and 55/55 engineering tests;
- formal dependency-local recovery statements under explicit assumptions;
- inspectable deterministic structural/demo evidence.

The planned five-task/14-run comparative study has not yet run. A demo paper can therefore align the paper's claim strength with the evidence actually available today.

## Required final emphasis

1. verification as a closed-loop execution control signal rather than post-hoc scoring;
2. one concrete worked execution/repair trace or deterministic structural demonstration;
3. dependency-local repair and evidence provenance;
4. runnable/inspectable implementation;
5. explicit limitation that comparative performance evidence is planned, not completed.

## Execution

Run `DEMO_PAPER_XHIGH_PROMPT.md` in a fresh GPT-5.6 XHigh session with the complete package attached. Human review and submission remain external release gates.
