# Build status — v5.6.35

- Current PDF: **8 pages total** under the package fallback style.
- Route: **full paper**.
- Responsible-use statement retained.
- Comparative workshop experiment: **0/14 scored runs**; empirical insertion remains pending.
- Main missing research evidence: targeted Flat-vs-Workflow experiment.
- Phase 01 must verify/rebuild under the authoritative NeurIPS 2026 author kit before submission.
