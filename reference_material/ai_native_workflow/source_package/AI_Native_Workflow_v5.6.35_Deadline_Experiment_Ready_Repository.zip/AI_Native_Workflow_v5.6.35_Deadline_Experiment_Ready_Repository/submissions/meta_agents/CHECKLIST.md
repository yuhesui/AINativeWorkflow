# Meta-Agents submission checklist — v5.6.35

Status: **substantive anonymous draft; empirical insertion and Phase 01 release/template audit remain**.

- [x] Venue-specific manager/worker and compound-agent framing.
- [x] Persistent-contract / DIC / EPS execution semantics described materially.
- [x] Independent source tree and compiled PDF.
- [x] Anonymous author line; no identifying acknowledgement.
- [x] Full-paper draft currently within the workshop's <=9 main-text-page allowance (see `BUILD_STATUS.md`).
- [x] Mandatory responsible-use statement included.
- [x] Five-task/14-run protocol written without fabricated results.
- [x] Engineering evidence separated from agent-performance evidence.
- [ ] Phase 01: fetch/verify authoritative NeurIPS 2026 author kit and rebuild double-blind PDF.
- [ ] Phases 03–05: execute/reconcile scored study.
- [ ] Phase 06: generate result tables from raw evidence and insert only supported claims.
- [ ] Fresh correctness/novelty/citation/anonymity/release audit.
- [ ] Re-open official workshop page immediately before upload and reconfirm deadline/forms/page accounting.
- [ ] Human confirmation before external submission.
