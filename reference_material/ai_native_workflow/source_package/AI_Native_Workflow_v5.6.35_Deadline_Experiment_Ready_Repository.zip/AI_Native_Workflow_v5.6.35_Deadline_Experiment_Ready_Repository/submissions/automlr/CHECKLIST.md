# AutoMLR checklist — v5.6.35

Status: **CONDITIONAL / NOT SUBMISSION-READY**.

- [x] Eligibility assessed before treating the workflow system as sufficient.
- [x] Three-part Part I / Part II / Part III scaffold present.
- [x] Candidate Part I study is concretely specified but explicitly unexecuted.
- [x] Part II/III carry visible human-rewrite requirements; AI-generated notes are not disguised as human prose.
- [x] No qualifying ML result, abstract registration, or human authorship status fabricated.
- [ ] Immediately verify whether an abstract registration exists and remains valid.
- [ ] Complete a qualifying autonomous-ML result and independently audit the autonomy/evidence claim.
- [ ] Human author(s) rewrite Part II as required by workshop policy and complete Part III reflections.
- [ ] Phase 01: integrate authoritative NeurIPS 2026 author kit / required AutoMLR formatting and rebuild.
- [ ] Recheck first-author/reviewer/attendance/page-allocation requirements in live instructions.
- [ ] Human confirmation before any external submission.
