# AutoMLR abstract-registration state

## Current factual state

- Current package scored workshop runs: **0/14**.
- The planned five-task Flat-vs-Workflow study therefore does **not yet provide an established qualifying ML result**.
- AutoMLR explicitly requires both a qualifying autonomous ML research result and the autonomous-system account; a systems-only workflow paper is insufficient.
- The qualifying result must appear in the abstract.

## Immediate action

Run `AUTOMLR_ABSTRACT_XHIGH_PROMPT.md` in a fresh GPT-5.6 XHigh session with the complete package attached.

The session must first search the package for an already-established qualifying autonomous ML result. It may draft a submit-ready abstract only if the evidence supports eligibility. Otherwise it must return an internal scaffold labelled `NOT YET ELIGIBLE`.

## Revision boundary

OpenReview abstract-registration workflows commonly allow title/abstract/paper revisions before the final paper deadline when the venue enables that stage, but this must be confirmed on the live AutoMLR submission form. Later revision does **not** justify fabricating a qualifying result at registration time or changing to an unrelated project.
