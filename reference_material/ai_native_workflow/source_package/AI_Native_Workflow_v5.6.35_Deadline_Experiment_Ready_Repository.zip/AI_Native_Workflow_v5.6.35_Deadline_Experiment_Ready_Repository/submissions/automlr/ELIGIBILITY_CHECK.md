# AutoMLR eligibility check — v5.6.35

## Current decision

**NOT YET SUBMISSION-READY / eligibility not yet established from this package alone.**

AutoMLR requires both:

1. a qualifying machine-learning research result for which an autonomous agent conducted the research end-to-end or made a decisive contribution to the primary result; and
2. a detailed account of the autonomous system that produced it.

A systems-only AI-Native Workflow paper is explicitly insufficient, and the qualifying result must be stated in the abstract.

## Current evidence boundary

The package's planned five-task Flat-vs-Workflow study remains **0/14 scored trajectories completed**. Therefore the study cannot currently be described as an established qualifying ML result.

An already-existing package-resident ML result could still qualify if a fresh provenance audit shows the autonomous system's contribution was decisive. That audit has not yet been completed. Use `AUTOMLR_ABSTRACT_XHIGH_PROMPT.md` immediately.

## Abstract registration timing

The official workshop page lists an extended **August 29, 2026 abstract deadline** and **September 5, 2026 final submission**. The workshop page states that exact time zones are supplied with submission instructions, so the live OpenReview form is authoritative. Registration status is unknown until checked by the human user.

OpenReview registration workflows may permit revisions before final submission when enabled by the venue, but editability does not permit fabricating a qualifying result or changing to an unrelated project.

## Eligibility gates

The paper becomes potentially eligible only if all are true:

1. abstract registration is valid/on time;
2. Part I contains a real established ML research result;
3. autonomous contribution satisfies the workshop's decisive/end-to-end criterion;
4. human interventions/provenance are disclosed honestly;
5. the qualifying result appears in the abstract;
6. Part II is rewritten/authored as required by the human-authorship/disclosure policy;
7. Part I ≤4 pages, Part II ≤4 pages, Part III ≤1 page;
8. blind-review, reviewing, first-author, and in-person requirements are satisfied.

## Package treatment

`main.tex` remains a conditional scaffold. It must not be promoted to submission-ready until the eligibility audit and qualifying-result gate pass.
