# GPT-5.6 XHigh — AutoMLR 2026 Eligibility Audit and Abstract Registration

## Role

Act as an independent senior machine-learning researcher, AutoMLR eligibility auditor, autonomous-research provenance auditor, and scientific editor.

Use GPT-5.6 XHigh reasoning quality throughout.

The complete current AI-Native Workflow package is attached. The immediate task is to determine the strongest scientifically honest abstract that can be registered for **AutoMLR @ NeurIPS 2026**. Do not write the full paper in this session unless needed only to assess viability. Do not manufacture a qualifying result.

## Verify the live rules first

Check the official AutoMLR page and live submission instructions. Verify at minimum:

- abstract and final-paper deadlines/timezone;
- whether title/abstract can be revised before final submission;
- qualifying autonomous-ML-research criterion;
- required 4 + 4 + 1 structure;
- abstract requirement;
- human-authorship/disclosure expectations;
- double-blind requirements;
- reviewing/in-person constraints.

Current substantive rule expected from the official page:

- every submission must contain a **qualifying ML research result** plus the system account;
- an autonomous agent must have conducted the ML research end-to-end or made a decisive contribution to the paper’s primary result;
- without the agent contribution, the result could not have been established or the main conclusions would materially differ;
- the qualifying result must appear in the abstract;
- systems-only workflow papers do not qualify.

If live rules differ, live rules win and record the difference.

## Evidence-first package audit

Read the full package as evidence, not marketing material. Inspect at minimum:

- `00_READ_FIRST.md` and `.ai-workflow/STATE.json`;
- `MAIN_REPORT.md`;
- detailed technical report;
- claim ledger/theory/literature files;
- experiment protocol and scored-run status;
- Phase reports and raw evidence;
- current AutoMLR scaffold;
- any package-resident autonomous ML result.

Distinguish carefully between:

1. AI-Native Workflow as an agent system;
2. experiments evaluating AI-Native Workflow;
3. an ML research result produced or decisively advanced by AI-Native Workflow.

Only category 3 can serve as AutoMLR Part I.

## Central eligibility audit

Enumerate every plausible candidate result in the package and for each ask:

### A. Is it genuinely ML research?

It must concern an ML research hypothesis/method/result rather than only workflow engineering, CLI/tooling, harness design, documentation, or generic software engineering.

### B. What exactly is the primary result?

State it concretely and evidence-first.

### C. What did the autonomous agent actually do?

Recover evidence for hypothesis formation, method/theory construction, implementation, experiment design/execution, analysis, and writing.

### D. Was the contribution decisive?

Apply the counterfactual: without the autonomous agent’s contribution, could the result already have been established from human-provided material?

Classify each candidate as:

- QUALIFIES STRONGLY;
- LIKELY QUALIFIES;
- BORDERLINE;
- DOES NOT QUALIFY;
- INSUFFICIENT EVIDENCE.

### E. Is the result already established?

Planned experiments, speculative hypotheses, unfinished theory, and smoke/fixture evidence do not count as an established qualifying ML result.

## Important current boundary

The package currently records **0/14 scored workshop trajectories** unless new evidence in the attached package says otherwise. Therefore do not assert that the planned Flat-vs-Workflow study already produced a qualifying result.

Do not use the AI-Native Workflow system itself as Part I merely because it is sophisticated. AutoMLR requires the ML research result and the autonomous system account separately.

## Candidate selection

Select exactly one strongest candidate only if it is:

1. already established;
2. clearly ML research;
3. genuinely produced or decisively advanced by autonomous execution;
4. directly evidence-backed;
5. capable of supporting a strong ≤4-page Part I by the final deadline;
6. accompanied by transparent human/agent provenance.

If none qualifies, say so explicitly. Do not force eligibility.

## Abstract drafting

### If eligible

Draft a submit-ready abstract of roughly 150–250 words unless the live portal specifies another limit. Put the qualifying ML result in the abstract explicitly.

Suggested allocation:

- 70–80% qualifying ML research/result;
- 20–30% autonomous system/provenance.

Order:

1. ML problem;
2. autonomous-research setup;
3. concrete agent scientific contribution;
4. primary result;
5. supporting evidence;
6. brief system/provenance sentence;
7. significance/limitation.

Do not overclaim autonomy or spend most of the abstract describing AI-Native Workflow.

### If real result exists but exact final numbers are still being frozen

Write the strongest conservative registration abstract supported by current evidence. Keep uncertain final numerical values outside the submit-ready text as internal notes. Do not put hypothetical outcomes into the actual candidate abstract.

### If no qualifying result exists

Return exactly:

`AUTOMLR ELIGIBILITY: NOT YET ESTABLISHED`

Then provide:

1. closest candidate;
2. missing evidence;
3. whether it is realistically obtainable before final submission;
4. an **INTERNAL ONLY — NOT CURRENTLY ELIGIBLE FOR SUBMISSION** abstract scaffold showing where the future qualifying result would go.

Do not fabricate an eligible abstract merely to preserve a registration slot.

## Registration/final-paper distinction

If the live OpenReview workflow allows revisions before the final deadline, optimize registration text for stability of the underlying research question while allowing later refinement of exact values/wording. However, later editability does not permit an invented current result or an unrelated final paper.

## Eventual paper viability map

After the abstract decision, give a compact plan:

### Part I ≤4 pages — autonomous ML result
Hypothesis, method, evidence, primary result.

### Part II ≤4 pages — system design
AI-Native Workflow Main/DIC/EPS/tools/research loop/interventions/verification/provenance. Treat the workshop’s expected human-written Part II requirement seriously; do not disguise generated prose as human-authored.

### Part III ≤1 page — human reflections
Human judgment, interventions, failures, implications.

## Package updates

Update/create as appropriate:

- `submissions/automlr/ELIGIBILITY_CHECK.md`;
- `submissions/automlr/ABSTRACT_REGISTRATION.md`.

Do not silently overturn a previous negative eligibility assessment without identifying the new evidence that changes it. Do not submit externally.

## Final output

Return:

### A. Eligibility verdict
One of: QUALIFIES STRONGLY / LIKELY QUALIFIES / BORDERLINE / NOT YET ELIGIBLE / NOT ELIGIBLE.

### B. Selected qualifying ML result
One precise paragraph.

### C. Submit-ready abstract
Only if eligible; otherwise the clearly labelled internal scaffold.

### D. Agent-contribution statement
2–4 sentences.

### E. Remaining work before final submission
Maximum five concrete items.

### F. Files written/updated
