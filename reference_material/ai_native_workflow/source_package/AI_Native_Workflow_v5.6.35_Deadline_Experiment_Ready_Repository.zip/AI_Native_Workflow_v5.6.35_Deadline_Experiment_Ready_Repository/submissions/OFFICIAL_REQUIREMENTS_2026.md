# NeurIPS 2026 workshop requirements snapshot

Retrieved/verified from official workshop pages: **2026-08-30, Singapore time**. Live venue/OpenReview instructions remain authoritative.

## Managing Agents that Manage Agents

Official page: https://meta-agents-workshop.github.io/

- Submission deadline: **September 5, 2026 AoE**.
- Full papers: **≤9 main-text pages**; short papers ≤4 pages.
- Demo track is also offered.
- NeurIPS 2026 or ICLR 2027 LaTeX template.
- **Double blind**.
- **Mandatory responsible-use statement**; omission is grounds for desk rejection.
- Non-archival.
- Accepted papers are posters; a subset is selected for oral/spotlight.

Current package route: **full paper**, with experiment results to be inserted after the targeted proof-of-concept study.

## Who Verifies the Agents?

Official page: https://verify-agents-workshop.github.io/

- Submission deadline: **August 29, 2026 at 23:59 AoE**, equivalent to **August 30, 2026 at 19:59 Singapore time**.
- Regular papers: **4–9 pages**, excluding references/appendices.
- **Demo papers: ≤4 pages**.
- NeurIPS 2026 template.
- Double blind.
- Non-archival; permissive dual/recent-publication policy per workshop page.
- Accepted papers are posters; select papers receive oral/lightning presentations.

Current package route: **≤4-page demo paper**. The retained 5-page research draft is not the intended final submission.

## AutoMLR — Workshop for Autonomous Machine Learning Research

Official page: https://automlr.com/

- Abstract deadline: **August 29, 2026** (extended from Aug 22).
- Final submission: **September 5, 2026** (extended from Aug 29).
- The workshop page states exact time zones are provided with submission instructions; the live OpenReview form is authoritative.
- Every paper must contain both a **qualifying ML research result** and a detailed account of the autonomous system.
- The autonomous agent must have conducted the ML research end-to-end or made the decisive contribution to the primary result.
- The qualifying result **must appear in the abstract**.
- Systems-only papers are not eligible.
- Part I result: ≤4 pages; Part II system design: ≤4 pages; Part III reflections: ≤1 page; limits cannot be reallocated.
- Blind submission.
- Authorship remains exclusively human; the workshop expects Part II to be human-written and requires transparent agent involvement/disclosure.
- Reviewing commitment, first-author restriction, and in-person participation requirements apply.

Current package route: **eligibility/provenance audit first**. Do not register a result claim that is not already established.

## Template rule

Use the authoritative NeurIPS 2026 author kit from https://neurips.cc/Conferences/2026/CallForPapers . The repository retains a fallback style only for offline compilation. Phase 01 must fetch/verify the official kit and rebuild before external upload.
