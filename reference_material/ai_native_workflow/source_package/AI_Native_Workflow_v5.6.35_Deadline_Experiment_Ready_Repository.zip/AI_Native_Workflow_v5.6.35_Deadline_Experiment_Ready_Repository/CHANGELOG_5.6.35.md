# Changelog — v5.6.35

## Deadline and publication routing

- Switched the intended **Who Verifies the Agents?** submission from the retained 5-page research-style draft to a **≤4-page demo paper** better matched to the current implemented-system evidence.
- Added `submissions/who_verifies/DEMO_TRANSITION.md` and a full GPT-5.6 XHigh reconstruction prompt.
- Added an AutoMLR-specific GPT-5.6 XHigh **eligibility/provenance audit + abstract-registration** prompt.
- Added `submissions/automlr/ABSTRACT_REGISTRATION.md` and tightened the eligibility boundary: 0/14 scored workshop trajectories means the planned benchmark cannot yet be represented as a qualifying result.
- Added `NEXT_ACTIONS_NOW.md` with absolute deadline ordering and explicit human release gates.

## Research state

- Preserved the frozen five-task/14-run workshop proof-of-concept design unchanged.
- Added `experiments/workshop_poc/WHAT_REMAINS.md` clarifying that the experiment is now the dominant remaining **scientific** task, while Phase 01 engineering and deadline submission work remain operational prerequisites.
- No benchmark result, theorem, citation, or acceptance claim was added or strengthened.

## Versioning

- Promoted current runtime/package metadata to v5.6.35 while preserving v5.6.31–v5.6.34 historical changelogs/tags.
- GitHub publication remains deferred to the authorized Phase 01 coding-agent action.
