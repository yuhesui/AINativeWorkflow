# AI-Native Workflow 5.6.35

AI-Native Workflow is a package-resident control layer for long-horizon language-agent research and engineering. The canonical hierarchy is:

> **Goal → Plan → Phase → DIC → EPS → Prompt/Run → Action**

Version **5.6.35** preserves the detailed v5.6.33 multi-view DIC/runtime architecture and the v5.6.34 five-task/14-run workshop programme, while updating the immediate publication strategy for the current deadline window.

## What to do now

Read `NEXT_ACTIONS_NOW.md` first.

1. **Who Verifies:** run the package-specific XHigh prompt and reconstruct the retained 5-page research draft into a **≤4-page demo paper**. The demo route matches the implemented-system evidence without waiting for the benchmark study.
2. **AutoMLR:** run the separate XHigh eligibility/provenance audit and draft/register an abstract only if a real qualifying autonomous ML result can honestly be stated.
3. **Phase 01:** give `NEXT_PHASE01_CODING_AGENT_HANDOFF.md` to the coding-agent run for CLI/repository/GitHub/environment preparation.
4. **Experiment:** qualify/freeze environments, then execute the five-task Flat-vs-Workflow proof of concept. This is now the dominant remaining scientific work for Meta-Agents and any benchmark-derived AutoMLR result.

## Workshop experiment

Frozen task families:

- SlopCodeBench: `env_manager`, `database_migration`, `recli`;
- Terminal-Bench: `live-database-cutover`;
- Terminal-Bench-Science: `certified-sparse-regression`.

Conditions are competent **Flat (F)** versus full **Workflow (W)**. ChatGPT is Main in every scored run. Claude Pro A executes the 10 primary trajectories; Claude Pro B is reserved for four pre-declared T2/T3 replications. **No scored result exists in v5.6.35.**

## Phase/DIC structure

Each Phase has one multi-view DIC package:

```text
DIC/
├── README.md          general Phase summary
├── REQUESTS.md        specific goals/acceptance requirements
├── PLAN.md            actual prompt graph, dependencies, parallel subagents, merges/branches
├── ARCHITECTURE.md?   target repository/system architecture when changed
├── TEST_MATRIX.md?    software/theory/experiment matrix when useful
├── <CUSTOM>.md?       arbitrary user-defined DIC views
└── MANIFEST.json
```

EPS is the disposable just-in-time instantiation of planned prompt/run nodes against current state, model/account availability, and repair history. Every Phase has a mandatory flat `reports/` surface with at most 10 files by default, including concise synthesis and key merged raw results.

See `.ai-workflow/docs/PHASE_DIC_EPS_STRUCTURE.md` and the detailed technical report.

## Repository state

This package is itself a local Git repository. Historical v5.6.33 and v5.6.34 tags are preserved; v5.6.35 is the deadline/execution-state release. No GitHub remote is created or pushed by this build. External repository publication remains a Phase 01 action after authentication/ownership checks.

## Basic validation

```bash
PYTHONPATH=.ai-workflow pytest -q .ai-workflow/tests
python .ai-workflow/aw_hierarchy.py --root . recover
```

The older `aw.py` Goal/Structured CLI remains a compatibility surface. Phase 01 is tasked with cleaning CLI ambiguity while preserving reasonable v5.6.31 usage.
