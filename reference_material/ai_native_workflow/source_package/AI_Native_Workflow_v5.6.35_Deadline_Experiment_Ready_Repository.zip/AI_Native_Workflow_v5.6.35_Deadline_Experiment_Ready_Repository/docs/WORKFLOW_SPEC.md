# Hierarchical execution specification

## Semantic levels

The canonical hierarchy is:

```text
Goal -> Plan -> Phase -> DIC -> EPS -> Prompt/Run -> Action
```

**Plan** is the human-facing strategic decomposition spanning several machine phases. **Phase** is a coherent machine-managed milestone and is not ordinarily a human approval boundary. **DIC** is one durable multi-view control package for the whole Phase. **EPS** is a disposable just-in-time instantiation of planned prompt/run nodes. **Prompt/Run** is one bounded agent execution; **Action** is actual tool use, editing, search, code execution, experiment, etc.

The DIC is **not** a list of sequential DIC-01/DIC-02 steps. Its required views are `README.md`, `REQUESTS.md`, and `PLAN.md`. `ARCHITECTURE.md`, `TEST_MATRIX.md`, and arbitrary user-defined Markdown views extend the same Phase contract when useful.

`DIC/PLAN.md` is deliberately an execution plan: it may specify tens or hundreds of prompt IDs, dependencies, parallel subagent batches, integration points and conditional repair/review branches. EPS then instantiates those durable nodes for the current state/model/context/attempt.

See `.ai-workflow/docs/PHASE_DIC_EPS_STRUCTURE.md` for the normative directory and file semantics.

## Boundaries

Machine execution boundaries occur at Phase, DIC, EPS, Prompt/Run and Action transitions. Human governance boundaries occur at initial Plan approval, periodic checkpoints, and immediate material escalation. Ordinary local repair is a machine decision when the DIC and frozen protocol remain unchanged.

## Roles

Main owns authority, architecture, Plan integration, state, and publication. Theory owns formal reasoning, literature/novelty, propositions and counterexamples. Experiment owns methods, implementations, statistics, and empirical evidence. Each active workstream orchestrates its own bounded execution; research/search is a capability, not a fourth persistent role.

## Optional lanes

`minor`, `research`, `verification`, and `checkpoints` support `off | auto | on`. `auto` is normally the default and materializes the lane only when needed. `reports/` is always present and cannot be disabled.

## Reports

Every Phase has a flat `reports/` directory with a default maximum of 10 files. It contains a concise human `REPORT.md` plus key merged raw results such as `RAW_RESULTS.jsonl`. Merged raw results are lossless collations with provenance; they must not silently average, paraphrase, round, filter failures or select favourable cases.

## Verification

Verification is a closed-loop operation with four outcomes: accept, repair, replan, escalate. Accept closes the relevant request/DIC gate. Repair regenerates or adjusts EPS under the same DIC. Replan changes durable execution design or Phase/Plan decomposition. Escalate requests human authority when a material boundary is crossed.

## State and evidence

`.ai-workflow/STATE.json` is the authoritative small index. Full DIC/EPS/Prompt/Action records and evidence remain package-local. Evidence pointers must resolve to actual files or immutable external identifiers. Planned results are never entered as completed evidence.
