# GPT-5.6-era prompting guide

An ordinary execution brief should fit on approximately one page and contain five things: the desired outcome; relevant domain and package authority; hard constraints; observable success/evidence criteria; and the deliverable. State autonomy and escalation boundaries once. Let the model choose the execution route unless the route itself is scientifically frozen.

Avoid repeating generic instructions, assigning ceremonial prompt numbers, requesting visible chain-of-thought, or duplicating the same authority across several status files. Ask for decisions, artifacts, evidence, tests, and concise rationale. Use a fresh independent context only at material evidence, claim-freeze, release, or submission boundaries.

The templates in `.ai-workflow/templates/hierarchical/` implement this structure for Main, Theory, and Experiment.
