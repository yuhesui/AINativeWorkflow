# Official prompting sources used for the redesign

Accessed 2026-08-30. Local snapshots are retained for audit; external documentation may change.

- OpenAI Cookbook, **GPT-5 prompting guide**: `research/official_sources/openai_gpt5_prompting_guide.html`.
- OpenAI Platform documentation, **Prompt engineering**: `research/official_sources/openai_prompt_engineering.html`.

The runtime applies the durable principles relevant to long-horizon work: specify the outcome and success criteria; provide authoritative context; make hard constraints and evidence requirements explicit; state autonomy/escalation once; define the output artifact; permit the model to choose ordinary execution details; remove contradictory/repeated instructions; and request decisions/evidence rather than private chain-of-thought.

The package does not freeze wording from a mutable guide. The templates are short semantic contracts and should be revalidated when the deployed frontier model or official guidance materially changes.
