# Operations and checkpoint policy

The default human checkpoint interval is seven completed ordinary phases; configure roughly five to ten for most research programmes. The interval is a governance cadence, not an execution granularity. A single Phase may contain 10–100+ machine prompts/runs under its `DIC/PLAN.md`.

## Ordinary machine loop

```text
recover Plan/Phase state
-> read the complete DIC package
-> follow/refine DIC/PLAN prompt graph
-> instantiate current nodes through EPS
-> run prompts/actions, often in parallel subagent batches
-> record raw evidence and logs
-> merge key raw results into the flat reports/ surface
-> reconcile REQUESTS and TEST_MATRIX
-> accept / repair / replan / escalate
```

The human does not approve each prompt or EPS instance.

## Optional lanes

`minor`, `research`, `verification`, and `checkpoints` support `off`, `auto`, or `on`. `auto` keeps the Phase tree small until the capability is first needed. A frozen experiment may set `minor=off`; a literature-heavy Theory Phase may set `research=on`.

## Reports invariant

`reports/` always exists. It has no subfolders and at most 10 files by default. `REPORT.md` is the human synthesis. One or more raw files preserve the key merged underlying records in their least-processed usable form. The full forensic archive can remain in `logs/` and `evidence/`.

## Checkpoints and escalation

A periodic checkpoint reviews objective drift, evidence quality, dependency invalidation, cost, unresolved scientific uncertainty, and release implications. It does not replay ordinary implementation decisions.

Immediate escalation bypasses the interval for material changes to objective, authority, scientific claim, frozen protocol, destructive/external actions, paid compute, credentials/private systems, release, or submission state.

Independent verification should be genuinely independent: fresh context, access to the evidence and frozen claims, and no authorship of the artifact under review. Local checks and lightweight milestone rechecks need not be independent sessions.
