# Next Phase 01 — Coding-Agent Handoff

## Authority

Execute **only** `phase-01-engineering-release-env` from approved Plan `plan-workshop-poc-evaluation`. The authoritative contract is the Phase's complete `DIC/` directory; `DIC/PLAN.md` is the durable prompt/dependency/parallel execution graph and the Phase `EPS/` contains materialized run instructions. ChatGPT Main retains integration and authority.

## Objective

Leave a clean, coherent, GitHub-publishable AI-Native Workflow repository with repaired canonical CLI surfaces, preserved version history, official workshop build/template handling, and reproducible local Harbor preparation for the five frozen benchmark tasks. **Do not run scored Flat/Workflow trials.**

## Required execution graph

1. **P01 Main:** recover package, inspect DIC/state/Git, run baseline tests/recovery/build checks, record actual defects.
2. **P02A Claude Pro A:** CLI audit/repair in `.ai-workflow/aw/` + CLI tests/docs only.
3. **P02B Claude Pro B:** repository hygiene/versioning/release preflight in non-overlapping metadata/build/release scope. Run P02A/P02B in parallel worktrees/branches where feasible.
4. **P03 Main:** merge and run full regressions, install/recovery/Git/secret/path checks.
5. **P04A Claude Pro A:** prepare Harbor task resolver/locks, prerequisite checks, F/W wrappers, run/evidence directories, and non-scored qualification for the five frozen tasks.
6. **P04B Claude Pro B:** fetch/verify the official NeurIPS 2026 author kit if network permits, replace fallback workshop formatting correctly, and compile all three drafts without inventing results. Run P04A/P04B in parallel after P03.
7. **P05 Main:** merge, test, recover, build PDFs, dry-run benchmark configuration, confirm scored count remains zero.
8. **P06 coding agent under Main:** `gh auth status`; create/select and push the intended GitHub repository and version tags only if account/ownership is unambiguous. Never force-push or commit credentials. If auth/ownership is unresolved, record BLOCKED and do not improvise.
9. **P07 Claude Code:** non-scored task/oracle/verifier/environment qualification only; no paid cloud purchase.
10. **P08 Main:** close Phase reports and create `experiments/workshop_poc/READY_FOR_PHASE02.md` with task locks/blockers and repository remote/commit status.

## Frozen benchmark set

- T1 SlopCodeBench `env_manager`
- T2 SlopCodeBench `database_migration`
- T3 SlopCodeBench `recli`
- T4 Terminal-Bench `live-database-cutover`
- T5 Terminal-Bench-Science `certified-sparse-regression`

Do not replace these silently. Do not expose oracle solutions to scored workspaces.

## Hard constraints

- Main is ChatGPT; coding subagents do not acquire publication/scientific authority.
- Preserve v5.6.31–v5.6.35 version/migration history and existing Git tags.
- No scored benchmark run in Phase 01.
- No paid compute/API purchase.
- No credential material in Git.
- No external submission.
- Keep Flat condition competent; do not design a straw-man baseline while preparing wrappers.
- Actual ChatGPT/Claude models surfaced by the products must be logged later rather than assumed from subscription names.

## Phase closure gate

Do not mark Phase 01 complete unless full tests/recovery/builds pass, repository status is reproducible, benchmark environments are either qualified or precisely blocked, official-template status is explicit, reports are updated with raw test/environment outputs, and scored-run count is still zero.
