# Read first — AI-Native Workflow 5.6.35

This package is the authoritative state for the current workshop deadline window and proof-of-concept programme. Do not infer progress from prior chats.

## Read in this order

1. `NEXT_ACTIONS_NOW.md` — immediate deadline ordering.
2. `.ai-workflow/STATE.json` — approved Plan/Phase authority.
3. `submissions/who_verifies/DEMO_TRANSITION.md` and `DEMO_PAPER_XHIGH_PROMPT.md` — immediate Who Verifies route.
4. `submissions/automlr/ABSTRACT_REGISTRATION.md` and `AUTOMLR_ABSTRACT_XHIGH_PROMPT.md` — immediate AutoMLR eligibility/abstract route.
5. `NEXT_PHASE01_CODING_AGENT_HANDOFF.md` — next coding-agent Phase after deadline-critical publication actions.
6. `experiments/FROZEN_CANDIDATE_PROTOCOL.md` and `experiments/workshop_poc/README.md` — principal remaining research programme.
7. `submissions/OFFICIAL_REQUIREMENTS_2026.md` — current venue requirements snapshot.
8. `AI_NATIVE_WORKFLOW_TECHNICAL_REPORT.pdf` — detailed operational/theoretical specification.

## Current state

- Version: **5.6.35**.
- Active approved machine Plan: `plan-workshop-poc-evaluation`.
- Next machine Phase: **Phase 01 — repository engineering, CLI cleanup, GitHub upload, and benchmark environment**.
- Phase 01: **pending / prepared for coding agents**.
- Scored workshop runs: **0/14**.
- Who Verifies: intended route is now **≤4-page demo paper**; retained 5-page draft is source material only.
- AutoMLR: **eligibility not yet established**; immediate XHigh provenance/abstract audit required.
- Meta-Agents: full-paper route retained; experiment is the main missing research evidence.
- Git: local repository with historical tags; no external remote/push yet.
- External submissions/actions performed by this package build: none.

Do not run scored F/W trajectories during Phase 01. Do not fabricate an AutoMLR qualifying result. Human confirmation remains required for OpenReview submission, GitHub ownership/remote creation, credentials, and paid compute.
