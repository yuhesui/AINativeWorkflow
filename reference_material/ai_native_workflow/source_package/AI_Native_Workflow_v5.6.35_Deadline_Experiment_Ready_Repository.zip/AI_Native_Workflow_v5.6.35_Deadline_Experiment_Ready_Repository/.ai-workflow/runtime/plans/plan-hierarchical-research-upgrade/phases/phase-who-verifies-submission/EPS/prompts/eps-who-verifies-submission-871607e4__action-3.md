# Historical EPS node action-3

- EPS: `eps-who-verifies-submission-871607e4`
- Plan node: `action-3`
- Reconstructed from v5.6.32 coarse execution record.

## Run instruction

update claim/state handoff
