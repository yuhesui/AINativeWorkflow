# Experiment programme — Requests

These are specific goals to resolve; they are not execution steps.

## ac-1

required artifacts exist

- Status: `satisfied`

## ac-2

local validation passes

- Status: `satisfied`

## ac-3

claim/evidence status is explicit

- Status: `satisfied`

## Evidence requirements

- `experiments/FROZEN_CANDIDATE_PROTOCOL.md`
- `experiments/EXPERIMENT_HANDOFF.md`
- `experiments/config/frozen_candidate.json`
