# Historical EPS node action-1

- EPS: `eps-formal-theory-fa7bf1d9`
- Plan node: `action-1`
- Reconstructed from v5.6.32 coarse execution record.

## Run instruction

inspect authoritative inputs and constraints
