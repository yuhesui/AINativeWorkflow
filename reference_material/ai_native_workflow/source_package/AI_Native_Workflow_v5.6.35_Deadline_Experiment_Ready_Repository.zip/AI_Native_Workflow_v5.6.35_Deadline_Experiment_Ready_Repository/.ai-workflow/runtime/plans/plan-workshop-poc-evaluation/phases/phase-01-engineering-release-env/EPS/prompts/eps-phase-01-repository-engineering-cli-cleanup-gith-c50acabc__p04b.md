# EPS eps-phase-01-repository-engineering-cli-cleanup-gith-c50acabc — P04B

- Plan node: `P04B`
- Depends on: P03
- Parallel group: `B`
- Subagent: `True`

## Run instruction

Claude Code Pro B: integrate authoritative NeurIPS 2026 workshop template if available, clean submission build surfaces, and compile all three drafts without invented results.
