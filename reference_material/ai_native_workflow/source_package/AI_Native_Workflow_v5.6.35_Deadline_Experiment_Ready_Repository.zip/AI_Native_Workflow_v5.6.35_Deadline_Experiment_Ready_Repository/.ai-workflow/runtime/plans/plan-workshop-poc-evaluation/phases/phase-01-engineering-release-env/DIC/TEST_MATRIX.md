# Phase 01 — Test / Environment Matrix

## CLI/install tests

| Batch | Surface | Required check |
|---|---|---|
| C1 | source CLI | `python .ai-workflow/aw.py --version`, `--help`, status/recover |
| C2 | installed CLI | isolated install, `aw --version`, `aw --help` |
| C3 | hierarchy lifecycle | Plan create → Phase add → approve → DIC → EPS → start/status/recover on temp repo |
| C4 | compatibility | reasonable v5.6.31/v5.6.33 migration fixtures remain readable |
| C5 | reports | flat, always present, ≤10 default, merged raw validation |
| C6 | repository | no secrets/absolute temp paths; clean Git status after generated outputs ignored |

## Benchmark qualification matrix

| Task | Resolve exact version | Local image/setup | Oracle/non-agent check | Sidecar/verifier check | Resource status | Final Phase01 state |
|---|---|---|---|---|---|---|
| T1 env_manager | required | required | required | n/a | record | pending |
| T2 database_migration | required | required | required | n/a | record | pending |
| T3 recli | required | required | required | container features | record | pending |
| T4 live-database-cutover | required | required | required | **required** | record | pending |
| T5 certified-sparse-regression | required | required | required | leakage/process review | record | pending |

## Submission build matrix

| Draft | Style target | Page target | Mandatory gate |
|---|---|---|---|
| Meta-Agents | NeurIPS 2026 double-blind workshop | ≤9 main pages | responsible-use statement |
| Who Verifies | NeurIPS 2026 double-blind | 4–9 main pages | verification framing / anonymity |
| AutoMLR | workshop template, blind | 4 + 4 + 1 | qualifying ML result + abstract registration + human-written Part II |
