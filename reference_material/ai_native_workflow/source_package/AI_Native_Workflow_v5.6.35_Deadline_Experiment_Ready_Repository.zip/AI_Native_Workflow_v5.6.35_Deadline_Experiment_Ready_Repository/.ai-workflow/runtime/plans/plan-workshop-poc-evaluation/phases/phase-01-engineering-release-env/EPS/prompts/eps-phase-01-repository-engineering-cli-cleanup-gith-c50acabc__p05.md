# EPS eps-phase-01-repository-engineering-cli-cleanup-gith-c50acabc — P05

- Plan node: `P05`
- Depends on: P04A, P04B
- Parallel group: `none`
- Subagent: `False`

## Run instruction

Main merge Batch B; full tests/recovery/builds/config dry runs; verify all scored records remain planned/unpopulated.
