# Formal theory — Requests

These are specific goals to resolve; they are not execution steps.

## ac-1

required artifacts exist

- Status: `satisfied`

## ac-2

local validation passes

- Status: `satisfied`

## ac-3

claim/evidence status is explicit

- Status: `satisfied`

## Evidence requirements

- `research/CLAIM_LEDGER.json`
- `research/THEORY_NOTE.md`
- `AI_NATIVE_WORKFLOW_TECHNICAL_REPORT.tex`
