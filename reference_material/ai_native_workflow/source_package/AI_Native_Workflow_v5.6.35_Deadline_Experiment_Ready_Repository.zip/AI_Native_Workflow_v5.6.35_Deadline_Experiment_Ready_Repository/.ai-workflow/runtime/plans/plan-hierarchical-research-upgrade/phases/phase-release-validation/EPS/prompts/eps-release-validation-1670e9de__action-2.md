# Historical EPS node action-2

- EPS: `eps-release-validation-1670e9de`
- Plan node: `action-2`
- Reconstructed from v5.6.32 coarse execution record.

## Run instruction

produce and locally validate required artifacts
