# Runtime architecture — Requests

These are specific goals to resolve; they are not execution steps.

## ac-1

required artifacts exist

- Status: `satisfied`

## ac-2

local validation passes

- Status: `satisfied`

## ac-3

claim/evidence status is explicit

- Status: `satisfied`

## Evidence requirements

- `.ai-workflow/aw/hierarchy.py`
- `.ai-workflow/tests/test_hierarchical_runtime.py`
- `build/logs/hierarchical_tests.txt`
