# Release validation — Execution Plan

## Purpose

Run tests, compile and inspect PDFs, reconcile claim/evidence links, and package the handoff

## Historical execution graph

> This Phase was executed under v5.6.32 before the richer multi-view DIC/EPS semantics were finalized. The nodes below are reconstructed only from the recorded execution stack; no unrecorded prompts are invented. Future phases should record the full 10–100+ prompt graph here before/during execution.

| EPS | Node | Objective | Depends on | Parallel/subagent group |
|---|---|---|---|---|
| `eps-release-validation-1670e9de` | `action-1` | inspect authoritative inputs and constraints | — | — |
| `eps-release-validation-1670e9de` | `action-2` | produce and locally validate required artifacts | — | — |
| `eps-release-validation-1670e9de` | `action-3` | update claim/state handoff | — | — |

## Required semantics for future edits

- Prompt IDs are stable internal references, not human approval boundaries.
- Explicitly declare dependencies and parallel subagent batches.
- Explicitly declare merge/integration prompts and conditional repair/review branches.
- EPS instantiates these planned nodes against current state/model/context; ordinary retries create new EPS instances rather than redefining Phase intent.
