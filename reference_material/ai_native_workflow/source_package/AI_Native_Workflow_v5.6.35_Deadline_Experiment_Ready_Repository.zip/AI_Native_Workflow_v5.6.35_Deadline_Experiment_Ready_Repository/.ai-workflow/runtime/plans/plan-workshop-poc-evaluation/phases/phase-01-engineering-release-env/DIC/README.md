# Phase 01 — Repository engineering, CLI cleanup, GitHub upload, and benchmark environment

## Summary

This is the next executable Phase and is intended for bounded coding agents under ChatGPT Main. It does **not** run the 14 scored benchmark trials. Its job is to make the package/repository clean enough to run them reproducibly.

- **Owner:** Main (ChatGPT chat)
- **Primary coding executor:** Claude Code / Claude Pro A
- **Secondary coding executor:** Claude Code / Claude Pro B
- **Plan:** `plan-workshop-poc-evaluation`
- **Downstream:** Phase 02 environment qualification and protocol freeze

## Read first

1. `DIC/REQUESTS.md`
2. `DIC/PLAN.md`
3. `DIC/ARCHITECTURE.md`
4. `DIC/TEST_MATRIX.md`
5. `DIC/GITHUB_RELEASE.md`
6. `DIC/BENCHMARK_ENVIRONMENT.md`
7. `experiments/FROZEN_CANDIDATE_PROTOCOL.md`
8. `experiments/workshop_poc/`

## Authority

The user has authorized repository cleanup and a GitHub upload in this Phase. Do not expose credentials, benchmark oracle artifacts, or private chat data. Do not buy compute or silently switch to paid Modal/Daytona/API execution.

## Done means

The canonical CLI/install path is coherent and tested; the local Git history/version files are preserved; GitHub publication is completed when authenticated access is available; benchmark setup is reproducible and task/environment locks are produced; scored-run directories/interfaces are ready but unexecuted.
