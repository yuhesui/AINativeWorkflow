# Phase 01 — Execution Plan

This is the durable execution graph. ChatGPT Main owns integration. Coding agents may refine implementation details through EPS, but must not reinterpret Requests.

## Batch 0 — Main recovery / baseline

### P01 — Recover repository and establish baseline
**Owner:** Main
**Targets:** R01–R07

Read the DIC, inspect Git status/version state, run the existing test/recovery/build smoke suite, and record concrete defects. Do not edit first and diagnose later.

---

## Batch A — parallel coding-agent cleanup

Run **P02A and P02B in parallel** using separate Claude Code worktrees/branches or otherwise non-conflicting write scopes.

### P02A — Canonical CLI audit and repair
**Subagent:** Claude Code / Pro A
**Targets:** R01
**Depends on:** P01
**Write scope:** `.ai-workflow/aw/`, CLI tests, canonical CLI docs only

Unify user-facing navigation around the hierarchical runtime; fix help/version/install/status/recover/lifecycle inconsistencies; keep cheap legacy aliases but prevent them from presenting an alternative authority model. Add focused tests for every repaired CLI path.

### P02B — Repository hygiene, versioning and release preflight
**Subagent:** Claude Code / Pro B
**Targets:** R02, R03
**Depends on:** P01
**Write scope:** repository metadata, `.gitignore`, manifests/version docs, build hygiene, release scripts/docs; do not modify core CLI implementation

Audit tracked generated files, stale logs, duplicated outputs, absolute paths and secret risks. Preserve historical changelogs/migrations. Prepare GitHub publication script/checklist without pushing yet.

### P03 — Main merge A and regression tests
**Owner:** Main
**Depends on:** P02A, P02B

Merge/reconcile both branches. Run full workflow tests, installation smoke, package recovery, Git integrity, and secret/path scans. Local repair only for defects within R01/R02.

---

## Batch B — parallel environment and paper-build preparation

Run **P04A and P04B in parallel** after P03.

### P04A — Harbor benchmark environment preparation
**Subagent:** Claude Code / Pro A
**Targets:** R04, R05, R07
**Depends on:** P03
**Write scope:** `experiments/workshop_poc/` plus minimal runner interfaces/tests

Inspect the installed/current Harbor CLI before writing commands. Create reproducible local setup, prerequisite checks, task-version resolver, environment lock, run-directory generator, F/W condition wrappers, evidence validation, and non-scored qualification commands for the five frozen tasks. Never copy oracle solutions into scored workspaces.

### P04B — Submission/build hygiene and official template integration
**Subagent:** Claude Code / Pro B
**Targets:** R06
**Depends on:** P03
**Write scope:** `submissions/`, build scripts/status only

Fetch the authoritative NeurIPS 2026 author kit if network access permits; configure double-blind workshop style correctly; compile all three drafts; preserve page-limit/eligibility markers. Do not insert invented results.

### P05 — Main merge B and release candidate validation
**Owner:** Main
**Depends on:** P04A, P04B

Run full tests, package recovery, LaTeX builds, report-surface validation, `git diff`, and benchmark-config dry runs. Confirm every planned scored run is still unexecuted.

---

## Batch C — external repository publication and environment qualification

### P06 — GitHub publish
**Subagent:** one coding agent under Main supervision
**Targets:** R03
**Depends on:** P05

Run `gh auth status`; inspect target account/repository before mutation. Create/select the intended repository only if it is clearly the user's target. Push the validated `main` branch and tags without force. Record remote URL and commit. Never commit credentials. If authentication/ownership is unresolved, stop with a precise blocked report.

### P07 — Non-scored task qualification
**Subagent:** Claude Code
**Targets:** R04, R07
**Depends on:** P05

Run local environment/oracle qualification for T1–T5 as feasible. This is **not** an F or W scored run. Record task availability, verifier/oracle stability and resource blockers. Do not purchase cloud compute.

### P08 — Phase 01 closeout
**Owner:** Main
**Depends on:** P06, P07 (P06 may be explicitly BLOCKED on credentials while all local work is complete)

Produce `reports/REPORT.md`, merged raw test/environment outputs, repository commit/remote status, and `experiments/workshop_poc/READY_FOR_PHASE02.md`. Reconcile R01–R07 and identify any required task replacement before Phase 02.

## Parallelism constraints

- P02A/P02B and P04A/P04B are the only pre-declared parallel pairs.
- Use separate branches/worktrees or non-overlapping write scopes.
- Main performs every merge.
- No coding subagent may change benchmark task selection or publication claims without Main replanning.
