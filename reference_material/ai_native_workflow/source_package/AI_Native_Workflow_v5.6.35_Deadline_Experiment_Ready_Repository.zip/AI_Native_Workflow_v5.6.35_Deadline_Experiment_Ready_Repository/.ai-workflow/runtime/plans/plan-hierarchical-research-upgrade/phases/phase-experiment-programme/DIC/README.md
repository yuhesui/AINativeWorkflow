# Experiment programme — DIC

## Summary

Freeze controlled conditions, graders, metrics, pilot boundaries and Experiment handoff

- **Owner:** Experiment
- **Plan:** `plan-hierarchical-research-upgrade`
- **Phase:** `phase-experiment-programme`
- **Dependencies:** phase-runtime-architecture
- **Lifecycle state:** `complete`

## Multi-view contract

This directory is one Durable Intent Contract package for the whole Phase. Its files are complementary views of the same objectives; they are not sequential DICs.

- `REQUESTS.md` records specific goals/acceptance requirements.
- `PLAN.md` records the durable execution graph: prompt nodes, dependencies, parallel/subagent batches, merge points and conditional branches.
- `ARCHITECTURE.md` and `TEST_MATRIX.md` are optional views used when relevant.
- Additional flat Markdown views may be added by the user and registered in `MANIFEST.json`.

EPS is the disposable JIT instantiation of planned prompt nodes.
