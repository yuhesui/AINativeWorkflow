# Phase 01 — Requests

These are goals, not sequential steps.

## R01 — Canonical CLI is coherent

Audit and fix the user-facing CLI so new work naturally uses Goal → Plan → Phase → DIC → EPS → Prompt/Run → Action. Remove or clearly quarantine contradictory legacy behavior while retaining inexpensive compatibility aliases.

**Acceptance:** clean install works; `aw --help`, `aw --version`, status/recovery and hierarchy lifecycle smoke paths work; tests cover repaired surfaces.

## R02 — Repository/package hygiene

Remove stale build detritus and duplicated generated artifacts where safe, add a correct `.gitignore`, retain all versioning/changelog/migration authorities, and preserve historical evidence rather than rewriting history.

**Acceptance:** repository is understandable from a fresh clone; no credentials/secrets or local absolute paths are committed; current version metadata is consistent.

## R03 — Git repository and GitHub publication

Preserve the local Git repository initialized from the v5.6.33 snapshot. After all cleanup/tests, use authenticated GitHub tooling to create or select the user-authorized repository, push `main` and version tags, and record the remote URL/commit. Do not force-push or overwrite an unrelated repository.

**Acceptance:** local history remains intact and, when credentials permit, remote default branch and tags match the validated local commit. If credentials/target ownership are unavailable, leave a precise blocked handoff rather than inventing success.

## R04 — Five benchmark environments prepared

Prepare local-first Harbor execution for T1–T5, resolve exact task versions, and create deterministic setup/run/evidence scripts. Validate environment/oracle behavior without running scored agent conditions.

**Acceptance:** `TASK_LOCK.json`, `ENVIRONMENT_LOCK.json`, setup scripts, qualification logs, and run-directory generator exist; every retained task is classified for Phase 02.

## R05 — Condition interfaces are enforceable

Implement or scaffold separate Flat (F) and AI-Native (W) run entry points so the two conditions cannot silently share forbidden hierarchy state or extra executor resources.

**Acceptance:** dry-run/config validation demonstrates the correct condition contract and run IDs from `RUN_MATRIX.csv`.

## R06 — Workshop sources remain buildable

Preserve the three authored workshop drafts and replace fallback NeurIPS styling with the official 2026 workshop template if it can be fetched from an authoritative source. Do not change scientific claims to make pages fit.

**Acceptance:** all three `.tex` sources compile or have a precise environment blocker; Meta-Agents responsible-use and anonymity requirements remain present; Who Verifies remains double-blind; AutoMLR eligibility warnings remain explicit.

## R07 — No scored evidence fabricated or leaked

Oracle/setup work must remain isolated from future scored workspaces. No result table may contain invented benchmark scores.

**Acceptance:** scored run records remain `PLANNED` and raw result fields unpopulated at Phase 01 closure.
