# EPS eps-phase-01-repository-engineering-cli-cleanup-gith-c50acabc — P07

- Plan node: `P07`
- Depends on: P05
- Parallel group: `none`
- Subagent: `True`

## Run instruction

Run non-scored local task/oracle qualification for T1–T5, record verifier/resource status, and do not buy cloud compute or expose oracle artifacts to scored workspaces.
