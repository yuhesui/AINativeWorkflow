# Experiment programme — Phase Report

- Status: `complete`
- Owner: `Experiment`
- DIC: `.ai-workflow/runtime/plans/plan-hierarchical-research-upgrade/phases/phase-experiment-programme/DIC`
- EPS instances: 1
- Recorded actions: 1

## Objective

Freeze controlled conditions, graders, metrics, pilot boundaries and Experiment handoff

## Evidence
- `experiments/FROZEN_CANDIDATE_PROTOCOL.md`
- `experiments/EXPERIMENT_HANDOFF.md`
- `experiments/config/frozen_candidate.json`

## Verification
- **accept** — Required artifacts and evidence boundaries are recorded; final release diagnostics remain authoritative.

## Raw merged results

`RAW_RESULTS.jsonl` collates the recorded action objects without averaging, paraphrasing, rounding or favourable filtering. Full source artifacts remain at the referenced evidence paths.
