# EPS eps-phase-01-repository-engineering-cli-cleanup-gith-c50acabc — P02A

- Plan node: `P02A`
- Depends on: P01
- Parallel group: `A`
- Subagent: `True`

## Run instruction

Claude Code Pro A: audit and repair canonical CLI/help/install/status/recover/lifecycle surfaces within .ai-workflow/aw and focused tests. Preserve cheap compatibility aliases.
