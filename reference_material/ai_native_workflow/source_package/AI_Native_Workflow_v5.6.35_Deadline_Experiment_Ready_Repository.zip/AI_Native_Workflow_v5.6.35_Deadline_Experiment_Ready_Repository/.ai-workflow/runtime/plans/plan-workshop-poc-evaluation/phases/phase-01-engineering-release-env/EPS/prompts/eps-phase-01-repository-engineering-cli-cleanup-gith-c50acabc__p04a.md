# EPS eps-phase-01-repository-engineering-cli-cleanup-gith-c50acabc — P04A

- Plan node: `P04A`
- Depends on: P03
- Parallel group: `B`
- Subagent: `True`

## Run instruction

Claude Code Pro A: prepare local Harbor/Docker benchmark environments, exact task locking, F/W wrappers, evidence validation, and non-scored qualification scripts for T1–T5.
