# Historical EPS node action-1

- EPS: `eps-automlr-eligibility-and-scaffold-f2c34a0d`
- Plan node: `action-1`
- Reconstructed from v5.6.32 coarse execution record.

## Run instruction

inspect authoritative inputs and constraints
