# EPS eps-phase-01-repository-engineering-cli-cleanup-gith-c50acabc — P06

- Plan node: `P06`
- Depends on: P05
- Parallel group: `none`
- Subagent: `True`

## Run instruction

Under Main supervision, inspect gh authentication/target repository, then publish validated main branch and version tags without force push; otherwise record exact credential/target blocker.
