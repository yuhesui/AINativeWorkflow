# Test / Experiment Matrix

This view records combinations/batches to test, not merely a prose acceptance checklist.

| Batch | Object/condition | Comparison/check | Evidence |
|---|---|---|---|
| A | recorded phase work | required artifact/evidence presence | package paths and raw records |
| B | runtime/recovery | lineage and package-only reconstruction | tests/build logs |
| C | C0/C1/C2/C3 (+ matched controls) | horizon/fault/branching conditions | planned confirmatory run records |
