# GitHub release contract

The user has requested that Phase 01 upload the cleaned package to GitHub.

1. Preserve the local `v5.6.33` and `v5.6.34` tags and the new `v5.6.35` history.
2. Before creating a remote, inspect `gh auth status` and the authenticated account.
3. Never store GitHub tokens, browser session files, `.claude` credentials, API keys, or Harbor cloud keys in the repository.
4. Never force-push or overwrite an existing unrelated repository.
5. Prefer repository name `AI-Native-Workflow` / `ai-native-workflow` if available; if an existing clearly intended repository is found, inspect it before pushing.
6. If repository visibility is not already specified by user/account context, do not make a public/private assumption silently; stop at the creation boundary and report the needed choice.
7. Push `main` and version tags only after P05 validation.
8. Record remote URL, branch, commit SHA and tag SHAs in Phase reports.
9. GitHub publication is repository release, not workshop submission; do not upload manuscripts to OpenReview.
