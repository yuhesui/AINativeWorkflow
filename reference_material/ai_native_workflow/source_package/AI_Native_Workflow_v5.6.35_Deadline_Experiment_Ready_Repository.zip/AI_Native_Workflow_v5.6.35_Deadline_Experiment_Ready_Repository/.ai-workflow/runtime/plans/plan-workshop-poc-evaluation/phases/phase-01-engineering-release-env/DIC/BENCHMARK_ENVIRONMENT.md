# Benchmark environment contract

Prepare the five task environments from `experiments/workshop_poc/TASK_CATALOG.md` using local Harbor/Docker first. Resolve exact versions into a lock file before scored execution.

- No scored F/W agent runs in Phase 01.
- Oracle/reference solutions may be used only for isolated environment qualification and must not enter future agent workspaces or prompts.
- No Modal/Daytona/API charges without separate human authorization.
- Claude Code authentication may be used from the user's existing Claude Pro sessions, but credentials must stay outside Git.
- Every executable wrapper must log task version, condition, run ID, account label, actual model identifier, start/end times and raw Harbor output path.
