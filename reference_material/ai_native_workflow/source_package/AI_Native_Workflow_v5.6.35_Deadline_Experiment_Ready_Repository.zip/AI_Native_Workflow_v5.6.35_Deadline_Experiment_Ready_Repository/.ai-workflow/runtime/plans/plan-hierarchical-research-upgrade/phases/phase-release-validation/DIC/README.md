# Release validation — DIC

## Summary

Run tests, compile and inspect PDFs, reconcile claim/evidence links, and package the handoff

- **Owner:** Main
- **Plan:** `plan-hierarchical-research-upgrade`
- **Phase:** `phase-release-validation`
- **Dependencies:** phase-meta-agents-submission, phase-who-verifies-submission, phase-automlr-eligibility-and-scaffold
- **Lifecycle state:** `complete`

## Multi-view contract

This directory is one Durable Intent Contract package for the whole Phase. Its files are complementary views of the same objectives; they are not sequential DICs.

- `REQUESTS.md` records specific goals/acceptance requirements.
- `PLAN.md` records the durable execution graph: prompt nodes, dependencies, parallel/subagent batches, merge points and conditional branches.
- `ARCHITECTURE.md` and `TEST_MATRIX.md` are optional views used when relevant.
- Additional flat Markdown views may be added by the user and registered in `MANIFEST.json`.

EPS is the disposable JIT instantiation of planned prompt nodes.
