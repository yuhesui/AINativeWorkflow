# Who Verifies submission — Requests

These are specific goals to resolve; they are not execution steps.

## ac-1

required artifacts exist

- Status: `satisfied`

## ac-2

local validation passes

- Status: `satisfied`

## ac-3

claim/evidence status is explicit

- Status: `satisfied`

## Evidence requirements

- `submissions/who_verifies/main.tex`
- `submissions/who_verifies/main.pdf`
- `submissions/who_verifies/CHECKLIST.md`
