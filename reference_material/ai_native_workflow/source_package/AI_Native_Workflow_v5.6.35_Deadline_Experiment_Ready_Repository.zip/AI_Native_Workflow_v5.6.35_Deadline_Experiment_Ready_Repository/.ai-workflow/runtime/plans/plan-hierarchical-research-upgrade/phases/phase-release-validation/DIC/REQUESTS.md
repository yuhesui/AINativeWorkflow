# Release validation — Requests

These are specific goals to resolve; they are not execution steps.

## ac-1

required artifacts exist

- Status: `satisfied`

## ac-2

local validation passes

- Status: `satisfied`

## ac-3

claim/evidence status is explicit

- Status: `satisfied`

## Evidence requirements

- `build/BUILD_STATUS.json`
- `build/BUILD_STATUS.md`
- `MAIN_REPORT.md`
