# Phase 01 — Target Repository Architecture

The target is a clean research repository, not a new conceptual rewrite.

```text
/
├── .ai-workflow/                 # canonical runtime, state, templates, tests
├── docs/                         # current operational/research docs; legacy quarantined
├── experiments/
│   ├── FROZEN_CANDIDATE_PROTOCOL.md
│   ├── FULL_RESEARCH_PROTOCOL_FUTURE.md
│   └── workshop_poc/
│       ├── README.md
│       ├── TASK_CATALOG.md
│       ├── CONDITION_SPEC.md
│       ├── RUN_MATRIX.csv
│       ├── TASK_LOCK.json        # produced Phase 01/02
│       ├── ENVIRONMENT_LOCK.json # produced Phase 01/02
│       ├── env/                  # setup/pinned environment scripts
│       ├── runners/              # F/W wrappers
│       ├── schema/
│       └── results/              # scored run records only; initially planned/unpopulated
├── research/                     # claim and novelty ledgers
├── submissions/
│   ├── meta_agents/
│   ├── who_verifies/
│   └── automlr/
├── build/                        # generated validation/build outputs, mostly gitignored
├── CHANGELOG_5.6.33.md           # retained history
├── CHANGELOG_5.6.34.md           # retained history
├── CHANGELOG_5.6.35.md
├── VERSIONING.md
└── PACKAGE_VERSION
```

## CLI target

Prefer one installed `aw` command with discoverable hierarchical groups. `aw_hierarchy.py` may remain an internal/compatibility entry point but should not be necessary for ordinary users. Legacy Goal/Structured commands may remain only where they map cleanly to canonical state or are explicitly marked compatibility-only.

## Git target

A normal `main` branch with the imported v5.6.33 snapshot tagged `v5.6.33`, v5.6.34 preparation tagged `v5.6.34`, current work committed/tagged `v5.6.35`, no credentials, no machine-specific benchmark state, and a remote configured only in P06.
