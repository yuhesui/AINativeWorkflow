# Historical EPS node action-2

- EPS: `eps-who-verifies-submission-871607e4`
- Plan node: `action-2`
- Reconstructed from v5.6.32 coarse execution record.

## Run instruction

produce and locally validate required artifacts
