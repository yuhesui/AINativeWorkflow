# EPS eps-phase-01-repository-engineering-cli-cleanup-gith-c50acabc — P03

- Plan node: `P03`
- Depends on: P02A, P02B
- Parallel group: `none`
- Subagent: `False`

## Run instruction

Main merge Batch A and run full regression/install/package recovery/git hygiene checks.
