# Historical EPS node action-3

- EPS: `eps-technical-report-a961654b`
- Plan node: `action-3`
- Reconstructed from v5.6.32 coarse execution record.

## Run instruction

update claim/state handoff
