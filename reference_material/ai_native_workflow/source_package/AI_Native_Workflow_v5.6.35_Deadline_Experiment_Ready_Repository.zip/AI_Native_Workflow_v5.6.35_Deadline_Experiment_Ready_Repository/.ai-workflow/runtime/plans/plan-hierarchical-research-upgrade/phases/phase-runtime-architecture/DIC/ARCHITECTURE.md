# Runtime architecture — Target Repository Architecture

```text
.ai-workflow/runtime/plans/<plan>/phases/<phase>/
├── DIC/
│   ├── README.md
│   ├── REQUESTS.md
│   ├── PLAN.md
│   ├── ARCHITECTURE.md?
│   ├── TEST_MATRIX.md?
│   ├── <CUSTOM>.md?
│   └── MANIFEST.json
├── EPS/
│   ├── <eps-id>.json
│   └── prompts/
├── actions/
├── logs/
├── evidence/
├── reports/                  # always present, flat, <=10 files by default
└── minor|research|verification|checkpoints/   # off|auto|on
```

The substantive repository outputs remain in their natural project locations; phase folders preserve control, execution and evidence lineage rather than duplicate the project tree.
