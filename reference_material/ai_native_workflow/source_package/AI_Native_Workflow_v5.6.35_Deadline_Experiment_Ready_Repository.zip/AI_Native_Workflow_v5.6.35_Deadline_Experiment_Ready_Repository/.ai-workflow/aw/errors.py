class WorkflowError(RuntimeError):
    pass
