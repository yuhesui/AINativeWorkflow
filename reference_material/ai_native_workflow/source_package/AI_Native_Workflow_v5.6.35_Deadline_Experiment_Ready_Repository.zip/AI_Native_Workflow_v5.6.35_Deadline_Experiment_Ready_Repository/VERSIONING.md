# Versioning — AI-Native Workflow v5.6.35

Current release: **v5.6.35**. The public report may use the stable family label **AI-Native Workflow 5.6**.

## Release lineage

- **v5.6.31** — richer legacy Goal/Structured phase machinery retained for migration/compatibility reference.
- **v5.6.32** — simplified hierarchical Plan/Phase/Main-Theory-Experiment reconstruction.
- **v5.6.33** — restored detailed multi-view DIC, prompt-graph/EPS semantics, optional execution lanes, flat capped reports, and full operational technical report.
- **v5.6.34** — workshop proof-of-concept planning release: local Git repository/version history, frozen five-task/14-run evaluation, prepared Phase 01 engineering/environment handoff, and materially written three-workshop manuscript drafts.
- **v5.6.35** — deadline/execution-state release: Who Verifies switched to the ≤4-page demo route, AutoMLR abstract-registration/eligibility audit prompt added, immediate next-action ordering recorded, and the experiment explicitly identified as the dominant remaining scientific gap.

Version numbers identify package/runtime releases, not evidence strength. v5.6.35 still contains **no scored benchmark result**. Experimental evidence is versioned separately by run record, benchmark/task lock, environment hash, and Git commit.

The local Git repository preserves annotated `v5.6.33`, `v5.6.34`, and `v5.6.35` history after final validation. Historical changelogs and migration material remain part of the package. GitHub publication is not implicit in a version bump; it remains a separately authorized Phase 01 action.
