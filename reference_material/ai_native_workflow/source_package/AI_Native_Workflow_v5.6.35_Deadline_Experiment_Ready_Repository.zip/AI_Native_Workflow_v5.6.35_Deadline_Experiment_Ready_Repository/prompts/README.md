# Deadline-critical XHigh prompts

The canonical prompt files live with their target submissions:

- `submissions/who_verifies/DEMO_PAPER_XHIGH_PROMPT.md`
- `submissions/automlr/AUTOMLR_ABSTRACT_XHIGH_PROMPT.md`

Use separate fresh GPT-5.6 XHigh sessions and attach the complete package to each. Do not merge these tasks into one session: the Who Verifies task is an aggressive demo-paper reconstruction, whereas AutoMLR must begin with a hostile eligibility/provenance audit.
