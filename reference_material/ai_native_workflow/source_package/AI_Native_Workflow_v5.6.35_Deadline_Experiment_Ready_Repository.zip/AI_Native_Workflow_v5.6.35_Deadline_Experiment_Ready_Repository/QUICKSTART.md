# Quick Start — AI-Native Workflow v5.6.35

## 1. Read the immediate execution order

```text
NEXT_ACTIONS_NOW.md
00_READ_FIRST.md
.ai-workflow/STATE.json
```

The active machine programme is `plan-workshop-poc-evaluation`, but the current deadline window has two publication actions before the next coding-agent Phase.

## 2. Deadline-critical publication actions

### Who Verifies

Run a fresh GPT-5.6 XHigh session with the full package and:

```text
submissions/who_verifies/DEMO_PAPER_XHIGH_PROMPT.md
```

The intended output is a **≤4-page demo paper**. The retained 5-page `main.tex` is source material only.

### AutoMLR

Run a separate fresh GPT-5.6 XHigh session with:

```text
submissions/automlr/AUTOMLR_ABSTRACT_XHIGH_PROMPT.md
```

This is an eligibility/provenance audit first. Do not fabricate a qualifying ML result merely to register an abstract.

## 3. Phase 01 coding-agent work

After those deadline actions, use:

```text
NEXT_PHASE01_CODING_AGENT_HANDOFF.md
```

or the canonical DIC:

```text
.ai-workflow/runtime/plans/plan-workshop-poc-evaluation/
  phases/phase-01-engineering-release-env/DIC/
```

Phase 01 cleans/fixes CLI/repository surfaces, prepares GitHub publication and benchmark environments, integrates the authoritative NeurIPS author kit, and performs non-scored qualification. **Do not run scored F/W trials in Phase 01.**

## 4. Workshop experiment

Read:

```text
experiments/FROZEN_CANDIDATE_PROTOCOL.md
experiments/workshop_poc/README.md
experiments/workshop_poc/RUN_MATRIX.csv
experiments/workshop_poc/WHAT_REMAINS.md
```

The study has five task families, Flat versus Workflow, ten primary trajectories on Claude Pro A, and four T2/T3 replications on Claude Pro B. ChatGPT is Main in all runs. Current scored count: **0/14**.

## 5. Validate the runtime

```bash
PYTHONPATH=.ai-workflow pytest -q .ai-workflow/tests
python .ai-workflow/aw_hierarchy.py --root . recover
```

## 6. Publication state

- Meta-Agents: full paper; experiment is main missing research evidence.
- Who Verifies: demo route; does not need the 14-run study to be a defensible implemented-system submission.
- AutoMLR: conditional; qualifying autonomous ML result mandatory.
