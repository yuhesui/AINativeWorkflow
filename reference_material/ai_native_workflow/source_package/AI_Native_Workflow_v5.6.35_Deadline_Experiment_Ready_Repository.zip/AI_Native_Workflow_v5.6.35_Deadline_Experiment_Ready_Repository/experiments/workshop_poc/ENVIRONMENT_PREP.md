# Benchmark environment preparation specification

Phase 01 owns environment preparation; scored runs begin only after this file's gates pass.

## Local prerequisites

Preferred environment:

- Linux or WSL2 with Docker Engine / Docker Desktop working;
- Python 3.11+;
- `uv`;
- Harbor CLI;
- Git;
- GitHub CLI (`gh`) for repository publication only;
- Claude Code installed and authenticated with the intended Claude Pro account;
- sufficient disk/RAM for benchmark containers.

Do not assume Modal/Daytona/API credentials. These are optional paid/external paths and require separate authorization.

## Bootstrap target

Phase 01 should produce deterministic scripts under `experiments/workshop_poc/env/` that:

1. check Docker and system prerequisites;
2. install/pin Harbor in an isolated environment;
3. resolve the exact task versions into `TASK_LOCK.json`;
4. verify Claude Code can execute a trivial disposable command in a sandbox;
5. execute each task's oracle or official environment smoke test without exposing oracle artifacts to future agent workspaces;
6. record environment versions to `ENVIRONMENT_LOCK.json`;
7. create clean run directories from `RUN_MATRIX.csv`.

## Harbor task commands (candidate syntax)

Resolve exact syntax against the installed Harbor version during Phase 01.

```bash
harbor run -t "gabeorlanski/env_manager@latest" -a oracle
harbor run -t "gabeorlanski/database_migration@latest" -a oracle
harbor run -t "gabeorlanski/recli@latest" -a oracle
harbor run -t "terminal-bench/live-database-cutover@latest" -a oracle
harbor run -t "terminal-bench-science/certified-sparse-regression@latest" -a oracle
```

Do not blindly run these commands if the installed CLI schema differs; Phase 01 must inspect `harbor --help` and the official dataset metadata first.

## Qualification gate

For each task record:

`available | oracle_pass | oracle_flaky | local_resource_blocked | verifier_issue | leakage_issue | replacement_required`

No scored run begins until all retained tasks are `available` with an acceptable oracle/environment check.
