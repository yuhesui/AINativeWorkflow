# Frozen candidate task catalog

## T1 — `gabeorlanski/env_manager@latest`

**Suite:** SlopCodeBench Harbor conversion. 5 progressive checkpoints; prior requirements remain active. Intended as the easier evolving-spec control. The benchmark reports core, isolated, strict, verbosity, and erosion dimensions.

**Why selected:** it tests whether the hierarchy incurs overhead when the task is relatively manageable while still having genuine checkpoint persistence.

**Pre-run qualification:** resolve exact Harbor task version; oracle once locally, then repeat if flaky. Record Docker/Harbor version.

## T2 — `gabeorlanski/database_migration@latest`

**Suite:** SlopCodeBench. 5 checkpoints. SQLite migration CLI progresses from DDL through transformations/backfills, constraints/rollback, and dependency management/topological sorting/cycle detection.

**Why selected:** strongest compact test of persistent requirements, dependencies, rollback, and repair locality.

**Replication:** primary Claude Pro A + independent Claude Pro B paired replication.

## T3 — `gabeorlanski/recli@latest`

**Suite:** SlopCodeBench. 8 checkpoints, hard. Hierarchical CLI expands through validation, YAML inheritance, aliases, formatting, caching, SQLite persistence, container orchestration, upgrade infrastructure, and system checks.

**Why selected:** longest small-budget evolving-spec task and the best proxy for cumulative architectural erosion.

**Replication:** primary Claude Pro A + independent Claude Pro B paired replication.

## T4 — `terminal-bench/live-database-cutover@latest`

**Suite:** current Terminal-Bench / TB4 task set. Live FastAPI/MySQL→PostgreSQL cutover under ongoing traffic and consistency checks.

**Why selected:** stateful, outcome-verified systems task where planning, monitoring, verification, and safe cutover matter more than writing isolated code.

**Qualification warning:** verifier depends on live sidecar state. Phase 01 must confirm the installed Harbor execution mode preserves the task's required sidecars and that the oracle is reliable locally. If local execution is not supported, do not silently move to paid cloud infrastructure.

## T5 — `terminal-bench-science/certified-sparse-regression@latest`

**Suite:** Terminal-Bench-Science. Mathematical sciences / optimization task requiring a certifiably near-optimal sparse-regression solution.

**Why selected:** adds a scientific/certification transfer task and checks that the workflow is not merely a coding-project organizer.

**Qualification warning:** inspect the final released task constraints and verifier before freeze; the task proposal noted that public reference implementations could affect difficulty. Retain the task only if the released anti-leak/process constraints make the comparison meaningful.

## Replacement rule

A selected task may be replaced only if Phase 01 finds a concrete verifier, environment, resource, or leakage defect. Replacement must be recorded before any scored result from that task is interpreted. Prefer a task from the same suite and role rather than choosing based on expected model performance.
