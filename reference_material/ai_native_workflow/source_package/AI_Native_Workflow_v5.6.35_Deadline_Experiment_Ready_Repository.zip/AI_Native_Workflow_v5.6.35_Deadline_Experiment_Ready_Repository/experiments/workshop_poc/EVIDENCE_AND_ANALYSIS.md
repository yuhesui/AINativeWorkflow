# Evidence and analysis specification

## Per-run raw record

Each scored run receives a stable `run_id` from `RUN_MATRIX.csv` and a directory under `experiments/workshop_poc/results/<run_id>/` containing, where available:

- `RUN.json` — condition/task/account/model/version/timestamps/status;
- `MAIN_TRANSCRIPT.*` or durable transcript reference;
- `EXECUTOR_TRANSCRIPT.*` / Claude Code logs;
- `HARBOR_RESULT.json` or exact verifier output;
- `RESOURCE.json` — turns/runs/wall time/token fields if surfaced;
- `ARTIFACTS.json` — hashes/pointers to final workspace artifacts;
- `REPAIR_TRACE.jsonl` — W only; explicit repair/replan events;
- `NOTES.md` — factual operator notes only.

## No manual aggregate transcription

Create manuscript tables and plots from raw files. A result is not publication evidence if it exists only in a Markdown summary.

## Primary small-sample presentation

- one row per run;
- paired F/W task table;
- SlopCodeBench checkpoint curves for T1–T3;
- independent-account replication panel for T2/T3;
- resource table;
- compact failure/repair trace table for illustrative cases with exact raw-log links.

## No inferential overclaim

Five task families do not justify broad frequentist population claims. Do not use p-values as the headline evidence. The workshop claim, if supported, is bounded to a targeted proof of concept.
