# Model/account budget

## Available budget

- **1× ChatGPT Plus** — reserved primarily for Main.
- **2× Claude Pro** — Claude Code execution accounts A and B.

No assumption of API credits is made. No paid cloud benchmark environment is authorized by this protocol.

## Allocation

### ChatGPT Plus

Use as Main for every F and W run. One fresh chat per run, persistent until that run closes. Avoid consuming this account on routine independent verification; Main should interpret objective benchmark tests itself unless a result is materially ambiguous.

### Claude Pro A

Primary Claude Code executor for the 10 core runs:

- T1 F/W
- T2 F/W
- T3 F/W
- T4 F/W
- T5 F/W

### Claude Pro B

Reserved for exactly four pre-declared replications:

- T2 F/W
- T3 F/W

Remaining credit may be used for a fresh-context audit after all primary runs, but not to selectively rescue a favorable condition.

## Cost reporting

Because subscription surfaces may not expose reliable per-run token counts, record:

- ChatGPT Main turns;
- Claude Code prompt/run count;
- wall time;
- benchmark timeout/termination;
- any token/cost information actually surfaced.

Do not fabricate token estimates from text length.
