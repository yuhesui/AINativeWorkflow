# Workshop proof-of-concept evaluation

This directory is the executable planning surface for the 5-task, 14-run workshop study.

## Read order

1. `../FROZEN_CANDIDATE_PROTOCOL.md`
2. `TASK_CATALOG.md`
3. `CONDITION_SPEC.md`
4. `RUN_MATRIX.csv`
5. `MODEL_BUDGET.md`
6. `ENVIRONMENT_PREP.md`
7. `EVIDENCE_AND_ANALYSIS.md`
8. `PHASE01_ENVIRONMENT_HANDOFF.md`

## Important boundary

The files here define **planned** evaluation. `results/` must remain absent/empty until actual runs occur. Never populate result fields from examples or expected outcomes.
