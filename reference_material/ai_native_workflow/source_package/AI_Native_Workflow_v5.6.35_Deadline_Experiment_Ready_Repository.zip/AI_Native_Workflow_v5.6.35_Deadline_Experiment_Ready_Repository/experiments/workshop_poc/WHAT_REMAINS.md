# What remains before research-level workshop evidence exists?

The experiment is now the dominant scientific gap.

## Already present

- implemented hierarchical runtime;
- detailed Phase/DIC/EPS/Prompt-Run specification;
- formal theory and claim ledger;
- literature/novelty synthesis;
- five-task/14-run targeted workshop protocol;
- Flat and Workflow condition definitions;
- run/evidence schemas;
- substantive venue-specific manuscript drafts.

## Still required

1. Phase 01 engineering/environment preparation;
2. Phase 02 exact task/environment/oracle qualification and freeze;
3. 10 primary paired Flat/Workflow runs;
4. 4 pre-declared hard-task replications if credits permit;
5. raw evidence merge and per-task/checkpoint analysis;
6. manuscript integration.

No broad population-level significance claim is intended from five task families. The workshop study is a targeted mechanism proof of concept. The larger C0-C3/horizon/fault programme remains future work.
