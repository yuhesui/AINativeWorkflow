# Condition specification

## Shared resources

Both conditions use:

- ChatGPT Plus as Main;
- Claude Code as the terminal executor;
- identical benchmark task/environment/version;
- identical network/tool permissions;
- identical benchmark timeout;
- the same primary Claude account for the paired run;
- fresh workspace and fresh Main chat.

The exact ChatGPT and Claude model identifiers visible at run time must be recorded.

## F — Flat competent workflow

Main receives the task and may produce one ordinary flat plan, delegate to Claude Code, inspect test results, and iterate. It may adapt intelligently. It must not instantiate the AI-Native DIC/EPS hierarchy or dependency-local repair protocol.

Required retained artifacts:

- `TASK_BRIEF.md`
- `FLAT_PLAN.md`
- raw Main transcript reference/export if available;
- Claude Code transcript/logs;
- Harbor/verifier outputs;
- final repository snapshot/hash.

## W — AI-Native Workflow

Main operates from the package and creates/uses the canonical Phase DIC. At minimum:

- `DIC/README.md`
- `DIC/REQUESTS.md`
- `DIC/PLAN.md`
- `DIC/TEST_MATRIX.md` for checkpoint/test mapping;
- EPS prompt/run records;
- raw executor evidence;
- repair/replan records;
- Phase `reports/` surface.

## Fairness rules

1. Do not give W benchmark-specific hints that F does not receive.
2. Do not give W extra oracle/test visibility.
3. Do not use Claude Pro B as a second worker inside W primary runs.
4. Local tests available to the task are available to both conditions.
5. If a shared environment bug is found, fix it for both conditions and rerun the affected pair.
6. Resource differences created by the workflow itself are measured, not hidden.
