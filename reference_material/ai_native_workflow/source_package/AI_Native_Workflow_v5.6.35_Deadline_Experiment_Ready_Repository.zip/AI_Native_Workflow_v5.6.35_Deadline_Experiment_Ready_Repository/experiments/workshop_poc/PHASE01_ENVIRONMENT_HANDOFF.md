# Phase 01 environment handoff

Phase 01 must prepare the benchmark infrastructure but **must not execute the 14 scored agent runs**.

Deliver:

- pinned Harbor/environment setup;
- `TASK_LOCK.json`;
- `ENVIRONMENT_LOCK.json`;
- oracle/smoke validation logs;
- run-directory generator;
- F and W runner interfaces that enforce the condition contract;
- evidence schema/validator;
- a concise `READY_FOR_PHASE02.md` identifying any task replacement required.

The environment is considered ready only when a clean machine/repository checkout can reproduce setup and the selected tasks' non-agent qualification checks without hidden credentials in the repository.
