#!/usr/bin/env python3
from pathlib import Path
import csv, json
root=Path(__file__).resolve().parents[1]
rows=list(csv.DictReader((root/'RUN_MATRIX.csv').open(encoding='utf-8')))
out=root/'results'; out.mkdir(exist_ok=True)
for row in rows:
    d=out/row['run_id']; d.mkdir(exist_ok=True)
    p=d/'RUN.json'
    if not p.exists():
        row2=dict(row); row2['status']='PLANNED'; row2['result_fields_unpopulated']=True
        p.write_text(json.dumps(row2,indent=2)+'\n',encoding='utf-8')
print(f'initialized {len(rows)} planned run directories under {out}')
