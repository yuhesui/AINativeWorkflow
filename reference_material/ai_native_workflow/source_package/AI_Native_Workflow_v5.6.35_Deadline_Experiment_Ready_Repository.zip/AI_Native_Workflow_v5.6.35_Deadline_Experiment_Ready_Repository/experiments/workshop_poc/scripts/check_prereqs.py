#!/usr/bin/env python3
"""Non-destructive prerequisite probe for Phase 01 benchmark setup."""
from __future__ import annotations
import json, shutil, subprocess, sys

def probe(cmd):
    path=shutil.which(cmd)
    out={'command':cmd,'path':path,'available':bool(path)}
    if path:
        try:
            cp=subprocess.run([cmd,'--version'],capture_output=True,text=True,timeout=15)
            out['version_output']=(cp.stdout or cp.stderr).strip()[:1000]
            out['returncode']=cp.returncode
        except Exception as e:
            out['error']=repr(e)
    return out

items=[probe(x) for x in ['git','python','uv','docker','harbor','claude','gh']]
print(json.dumps({'python':sys.version,'tools':items},indent=2))
raise SystemExit(0 if all(x['available'] for x in items[:4]) else 2)
