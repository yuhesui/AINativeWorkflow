# Experiment package — current workshop proof of concept

The immediate candidate is `FROZEN_CANDIDATE_PROTOCOL.md`. The older/full factorial C0–C3 horizon/fault programme is preserved as `FULL_RESEARCH_PROTOCOL_FUTURE.md` for later research.

For the current workshop study, read `workshop_poc/README.md` and its task catalogue, condition contract, model budget, run matrix, environment-preparation guide, run schema, and evidence/analysis rules. The current design has five task families and 14 scored runs. ChatGPT is Main; Claude Pro A is the primary Claude Code executor; Claude Pro B is used only for four pre-declared T2/T3 replications and selective fresh-context checking.

No scored result is present. Phase 01 prepares the repository/environments without scored execution; Phase 02 qualifies/freezes exact benchmark revisions; Phases 03–04 run the study; Phase 05 reconciles evidence; Phase 06 updates manuscripts.
