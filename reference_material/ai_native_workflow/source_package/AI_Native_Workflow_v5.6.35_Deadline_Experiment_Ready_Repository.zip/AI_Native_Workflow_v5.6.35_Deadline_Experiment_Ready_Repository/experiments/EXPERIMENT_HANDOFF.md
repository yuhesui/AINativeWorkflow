# Experiment workstream handoff — workshop proof of concept

## Authority

Read `.ai-workflow/STATE.json`, `experiments/FROZEN_CANDIDATE_PROTOCOL.md`, and `experiments/workshop_poc/`. Do not reinterpret planned hypotheses as results. Main owns programme/publication authority; Experiment owns environment qualification, scored-run execution, raw evidence, and analysis.

## Phase boundary

Phase 01 is engineering/environment preparation and is **not a scored Experiment phase**. Phase 02 qualifies exact task versions/oracles/verifiers and freezes task locks. Phase 03 executes the ten core F/W runs with Claude Pro A. Phase 04 executes four pre-declared T2/T3 F/W replications with Claude Pro B. Phase 05 performs descriptive task/checkpoint analysis and reconciles claims.

## Frozen tasks

T1 `env_manager`; T2 `database_migration`; T3 `recli`; T4 `live-database-cutover`; T5 `certified-sparse-regression`. Resolve and record exact Harbor dataset/task versions before scoring. Replacement is allowed only pre-score for a documented environment/verifier/resource defect.

## Evidence contract

Every run must satisfy `workshop_poc/schema/RUN_RECORD_SCHEMA.json`, retain official grader output, task/environment lock, ChatGPT/Claude client+model identifiers, transcript pointer, artifact hashes, wall time, executor/Main counts, infrastructure validity, and repair/rework information. For SlopCodeBench retain checkpoint-level correctness/regression evidence. Do not hand-copy aggregate values into manuscripts.

## Analysis boundary

Report all five tasks individually and checkpoint curves where available. Do not use a p-value as evidence of general superiority from this five-task study. Null/adverse results remain evidence and must not trigger post-hoc task deletion.

## Escalate

Escalate any paid compute, credentials/external repository action outside the authorized Phase, task replacement after scoring begins, condition-definition change, unrecorded model/account substitution, grader defect affecting completed runs, or manuscript claim exceeding evidence.
