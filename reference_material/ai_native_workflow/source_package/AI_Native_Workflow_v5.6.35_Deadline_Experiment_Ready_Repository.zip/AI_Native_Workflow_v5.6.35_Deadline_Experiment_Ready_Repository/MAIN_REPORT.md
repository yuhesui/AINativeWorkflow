# Main report — AI-Native Workflow v5.6.35

**Package version:** 5.6.35  
**Current programme:** deadline-critical workshop release + targeted proof-of-concept evaluation  
**Scored evidence:** none yet (0/14)

## 1. Architecture

The detailed hierarchy remains Goal → Plan → Phase → one multi-view DIC → EPS → Prompt/Run → Action. DIC `PLAN.md` is the durable execution graph; EPS instantiates nodes JIT. Optional minor/research/verification/checkpoint lanes remain configurable and every Phase keeps a flat reports surface capped at 10 files by default.

## 2. Immediate publication routing

- **Who Verifies:** switch to the official ≤4-page demo route. The current 5-page research draft remains source material; a package-specific XHigh reconstruction prompt is ready. The demo can stand on implemented runtime, verification semantics, formal locality insight, and a concrete structural/runtime demonstration without waiting for comparative benchmark results.
- **AutoMLR:** eligibility is not yet established from this package. The planned workshop study is unexecuted and therefore cannot be described as a qualifying ML result. A separate XHigh provenance/eligibility audit prompt is ready; a submit-ready abstract may be produced only if an already-established qualifying result is found.
- **Meta-Agents:** retain the full-paper route. The experiment is the principal missing research evidence before final manuscript integration.

## 3. What remains scientifically?

**Mostly experiment.** Architecture, runtime, formal theory, literature synthesis, detailed technical specification, experiment protocol, evidence schemas, and substantive manuscript drafts already exist. The dominant missing scientific evidence is the targeted five-task comparison and the pre-declared replications.

This does not mean the only remaining work is experimental: immediate Who Verifies/AutoMLR release actions and Phase 01 engineering/environment setup still precede scored runs.

## 4. Evaluation programme

Five task families are frozen: SlopCodeBench `env_manager`, `database_migration`, and `recli`; Terminal-Bench `live-database-cutover`; Terminal-Bench-Science `certified-sparse-regression`. The primary comparison is competent Flat (F) versus full Workflow (W). Ten core runs use Claude Pro A; four pre-declared T2/T3 replications use Claude Pro B. ChatGPT is Main in every scored run.

## 5. Next machine Phase

`phase-01-engineering-release-env` remains fully prepared but unexecuted. Coding agents are instructed to clean/fix canonical CLI behavior, preserve repository/version history, prepare benchmark environments/wrappers without scored trials, integrate the authoritative NeurIPS author kit, and create/push the GitHub repository only when authentication and ownership are unambiguous.

## 6. Scientific boundary

The dependency-local recovery theorem, imperfect-verifier bounds, evidence-aliasing impossibility, and related formal statements retain their explicit assumptions/classification. v5.6.35 adds no empirical performance claim. Runtime tests and deterministic fixtures remain engineering/structural evidence, not comparative benchmark evidence.
