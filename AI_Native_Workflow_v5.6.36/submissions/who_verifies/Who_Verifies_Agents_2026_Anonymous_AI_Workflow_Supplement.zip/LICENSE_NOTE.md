# License and Use Note

This anonymous supplement is supplied for scholarly review and reproducibility inspection. Provider documentation is referenced by URL and distilled into operational guidance; full provider webpages are not redistributed.
