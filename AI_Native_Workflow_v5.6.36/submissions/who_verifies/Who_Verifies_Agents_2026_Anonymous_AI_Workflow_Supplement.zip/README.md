# Anonymous AI-Native Workflow Demo Supplement

This supplement contains the cleaned `.ai-workflow/` runtime used by the demo paper **Verification-Gated Hierarchical Execution: A Demo for Long-Horizon Agents**.

## Scope

- one Plan containing Phases;
- exactly one multi-view DIC per Phase;
- Core DIC views `README.md`, `REQUESTS.md`, and `PLAN.md`;
- disposable EPS attempts bound to the stable DIC;
- model/surface prompt-tuning metadata for model-executed EPS nodes;
- Action/evidence lineage;
- verification outcomes `accept`, `repair`, `replan`, and `escalate`;
- deterministic repair-to-accept trace;
- declared dependency impact-cone helper;
- package-only recovery checks.

The structural demo is not comparative LLM-performance evidence. The runtime does not automatically infer hidden dependencies or guarantee verifier correctness.

## Run the deterministic demo

```bash
python .ai-workflow/aw.py --root demo_repo demo \
  --workspace demo_repo \
  --output demo_trace.json
```

Expected essentials:

```text
verification: repair -> accept
one stable DIC
first EPS: 7 nodes
second EPS: repair source + 4 downstream nodes
retained: collect + theory
fresh-store recovery: ok=true
```

## Run the relevant checks

```bash
python -m unittest discover -s .ai-workflow/tests -v
```

No credentials, network access, paid service, or external system is required.
