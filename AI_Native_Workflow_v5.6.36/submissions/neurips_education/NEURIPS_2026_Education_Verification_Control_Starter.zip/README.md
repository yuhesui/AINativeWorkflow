# NeurIPS 2026 Education Track — Teaching-Materials Starter

**Concept:** Verification as execution control for long-horizon agents.

This is a development starter, not a final OpenReview upload. It contains the pedagogical slide plan, learner exercise, facilitator guide, annotated reading list, concept-PDF outline, and a CPU-only deterministic demo implementation.

The final submission still requires an original rendered slide deck, author details, an official-template two-page PDF, licensing/accessibility review, and final packaging below 200 MB.
